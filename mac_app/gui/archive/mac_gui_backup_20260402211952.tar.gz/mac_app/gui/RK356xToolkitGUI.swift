import AppKit
import Combine
import Foundation
import IOKit
import SwiftUI
import SystemConfiguration
import UserNotifications

struct ToolkitStatus: Decodable {
    struct Service: Decodable {
        let host: String?
        let port: Int?
        let interval: Int?
        let auto_usbnet_repair: Bool?
        let api_version: Int?
    }

    struct USB: Decodable {
        let mode: String?
        let product: String?
        let pid: String?
    }

    struct USBNet: Decodable {
        let iface: String?
        let current_ip: String?
        let expected_ip: String?
        let configured: Bool?
    }

    struct Board: Decodable {
        let ping: Bool?
        let ssh_port_open: Bool?
        let control_service: Bool?
    }

    struct Host: Decodable {
        let docker_daemon: Bool?
        let dev_image: Bool?
        let official_image: Bool?
        let rkflashtool_built: Bool?
        let usbnet_helper_installed: Bool?
    }

    let repo_root: String?
    let service: Service?
    let updated_at: String?
    let usb: USB?
    let usbnet: USBNet?
    let board: Board?
    let host: Host?
}

struct ActionResponse: Decodable {
    let ok: Bool?
    let action: String?
    let output: String?
    let output_tail: String?
    let log_path: String?
    let returncode: Int?
    let error: String?
}

struct StatusEnvelope: Decodable {
    let ok: Bool?
    let state: ToolkitStatus?
}

struct TransportStatusResponse: Decodable {
    let ok: Bool?
    let updated_at: String?
    let usb: ToolkitStatus.USB?
    let usbnet: ToolkitStatus.USBNet?
}

struct BoardStatusResponse: Decodable {
    let ok: Bool?
    let updated_at: String?
    let board: ToolkitStatus.Board?
}

struct HostStatusResponse: Decodable {
    let ok: Bool?
    let updated_at: String?
    let host: ToolkitStatus.Host?
}

struct ToolkitTask: Decodable {
    let id: String?
    let action: String?
    let status: String?
    let created_at: String?
    let updated_at: String?
    let log_path: String?
    let output_tail: String?
    let returncode: Int?
    let ok: Bool?
}

struct TaskResponse: Decodable {
    let ok: Bool?
    let action: String?
    let task: ToolkitTask?
    let error: String?
}

struct TelemetrySessionCommandResponse: Decodable {
    let ok: Bool?
    let session_id: String?
    let queued: Bool?
    let pending_events: Int?
    let error: String?
}

struct RunActionServiceResponse: Decodable {
    let ok: Bool?
    let action: String?
    let output: String?
    let returncode: Int?
    let task: ToolkitTask?
    let error: String?
}

struct ServiceEvent: Decodable {
    let event: String?
    let sequence: Int?
    let changes: [String]?
    let state: ToolkitStatus?
}

struct TaskServiceEvent: Decodable {
    let event: String?
    let task: ToolkitTask?
}

enum WorkspaceMode: String {
    case release
    case development

    var displayName: String {
        switch self {
        case .release:
            return "发布版"
        case .development:
            return "开发版"
        }
    }

    var symbolName: String {
        switch self {
        case .release:
            return "shippingbox.fill"
        case .development:
            return "hammer.fill"
        }
    }
}

enum ActionPrecondition {
    case checkHost
    case ensureUSBNet
    case authorizeKey
    case rebootLoader
    case rebootDevice
    case flash(String)
    case buildSync
    case buildSyncFlash
    case updateLogo(flashAfter: Bool)
    case updateDTB(flashAfter: Bool)
}

enum ActivityLevel: String {
    case info
    case success
    case warning
    case error

    var color: Color {
        switch self {
        case .info:
            return .blue
        case .success:
            return .green
        case .warning:
            return .orange
        case .error:
            return .red
        }
    }

    var symbol: String {
        switch self {
        case .info:
            return "info.circle.fill"
        case .success:
            return "checkmark.circle.fill"
        case .warning:
            return "exclamationmark.triangle.fill"
        case .error:
            return "xmark.octagon.fill"
        }
    }
}

struct ActivityEntry: Identifiable {
    let id = UUID()
    let timestamp = Date()
    let level: ActivityLevel
    let title: String
    let message: String
    let detail: String?
}

enum DeviceRecoveryContext {
    case flash
    case reboot

    var activityTitle: String {
        switch self {
        case .flash:
            return "刷写恢复"
        case .reboot:
            return "设备重启恢复"
        }
    }

    var initialLine: String {
        switch self {
        case .flash:
            return "刷写已完成，等待设备退出 Loader 并重启"
        case .reboot:
            return "已请求设备重启，等待设备重新枚举为 USB ECM"
        }
    }
}

struct StatusSnapshot: Equatable {
    let serviceRunning: Bool
    let usbMode: String
    let usbProduct: String
    let usbPid: String
    let usbIface: String
    let hostIP: String
    let usbConfigured: Bool
    let ping: Bool
    let ssh: Bool
    let controlService: Bool
    let dockerReady: Bool
    let usbnetHelperInstalled: Bool
}

struct DevelopmentInstallStatus: Equatable {
    var dockerReady = false
    var officialImageReady = false
    var releaseVolumeReady = false
    var hostImagesReady = false
    var rkflashtoolReady = false
    var codexAvailable = false
    var codexPluginInstalled = false
    var openCodeAvailable = false
    var npmReady = false
    var openCodePluginInstalled = false
    var updatedAt = ""
}

struct LocalArtifactValidationItem: Identifiable, Equatable {
    let id = UUID()
    let title: String
    let detail: String
    let ok: Bool
    let optional: Bool
}

struct LocalArtifactValidationState: Equatable {
    var checking = false
    var checked = false
    var ready = false
    var summary = "未选择本地安装包目录"
    var items: [LocalArtifactValidationItem] = []
    var failureDetail = ""
}

struct ToolkitUpdateStatus: Equatable {
    var currentVersion = "unknown"
    var remoteVersion = ""
    var configured = false
    var updateAvailable = false
    var checkedAt = ""
}

enum ToolkitGUIError: LocalizedError {
    case repoRootNotFound
    case cliNotFound(String)
    case invalidJSON(String)
    case commandFailed(String)
    case timeout(String)

    var errorDescription: String? {
        switch self {
        case .repoRootNotFound:
            return "未找到可用工具工作区。请安装发布版；如需开发版，请先准备开发目录后再切换。"
        case let .cliNotFound(path):
            return "未找到 rk356xctl：\(path)"
        case let .invalidJSON(output):
            return "返回结果无法解析。原始输出：\(output)"
        case let .commandFailed(message):
            return message
        case let .timeout(message):
            return message
        }
    }
}

enum ProcessExecutor {
    static func run(
        executableURL: URL,
        arguments: [String],
        currentDirectoryURL: URL,
        environment: [String: String]
    ) async throws -> (Int32, String) {
        try await withCheckedThrowingContinuation { continuation in
            DispatchQueue.global(qos: .userInitiated).async {
                let process = Process()
                process.executableURL = executableURL
                process.arguments = arguments
                process.currentDirectoryURL = currentDirectoryURL
                process.environment = environment

                let stdout = Pipe()
                let stderr = Pipe()
                process.standardOutput = stdout
                process.standardError = stderr

                do {
                    try process.run()
                    process.waitUntilExit()
                    let data = stdout.fileHandleForReading.readDataToEndOfFile() +
                        stderr.fileHandleForReading.readDataToEndOfFile()
                    let output = String(data: data, encoding: .utf8) ?? ""
                    continuation.resume(returning: (
                        process.terminationStatus,
                        output.trimmingCharacters(in: .whitespacesAndNewlines)
                    ))
                } catch {
                    continuation.resume(throwing: error)
                }
            }
        }
    }

    static func runSync(
        executableURL: URL,
        arguments: [String],
        currentDirectoryURL: URL,
        environment: [String: String]
    ) throws -> (Int32, String) {
        let process = Process()
        process.executableURL = executableURL
        process.arguments = arguments
        process.currentDirectoryURL = currentDirectoryURL
        process.environment = environment

        let stdout = Pipe()
        let stderr = Pipe()
        process.standardOutput = stdout
        process.standardError = stderr

        try process.run()
        process.waitUntilExit()
        let data = stdout.fileHandleForReading.readDataToEndOfFile() +
            stderr.fileHandleForReading.readDataToEndOfFile()
        let output = String(data: data, encoding: .utf8) ?? ""
        return (
            process.terminationStatus,
            output.trimmingCharacters(in: .whitespacesAndNewlines)
        )
    }
}

final class SystemEventMonitor {
    private let onEvent: @MainActor (String) -> Void
    private var notificationPort: IONotificationPortRef?
    private var matchedIterator: io_iterator_t = 0
    private var terminatedIterator: io_iterator_t = 0
    private var dynamicStore: SCDynamicStore?
    private var dynamicStoreSource: CFRunLoopSource?

    init(onEvent: @escaping @MainActor (String) -> Void) {
        self.onEvent = onEvent
    }

    deinit {
        stop()
    }

    func start() {
        startUSBMonitoring()
        startNetworkMonitoring()
    }

    func stop() {
        if matchedIterator != 0 {
            IOObjectRelease(matchedIterator)
            matchedIterator = 0
        }
        if terminatedIterator != 0 {
            IOObjectRelease(terminatedIterator)
            terminatedIterator = 0
        }
        if let source = dynamicStoreSource {
            CFRunLoopRemoveSource(CFRunLoopGetMain(), source, .commonModes)
            dynamicStoreSource = nil
        }
        if let port = notificationPort {
            if let source = IONotificationPortGetRunLoopSource(port)?.takeUnretainedValue() {
                CFRunLoopRemoveSource(CFRunLoopGetMain(), source, .commonModes)
            }
            IONotificationPortDestroy(port)
            notificationPort = nil
        }
        dynamicStore = nil
    }

    private func emit(_ reason: String) {
        Task { @MainActor in
            self.onEvent(reason)
        }
    }

    private func drain(iterator: io_iterator_t, reason: String) {
        var sawEvent = false
        while true {
            let service = IOIteratorNext(iterator)
            if service == IO_OBJECT_NULL {
                break
            }
            sawEvent = true
            IOObjectRelease(service)
        }
        if sawEvent {
            emit(reason)
        }
    }

    private func startUSBMonitoring() {
        guard notificationPort == nil else {
            return
        }
        guard let port = IONotificationPortCreate(kIOMainPortDefault) else {
            return
        }
        notificationPort = port
        if let source = IONotificationPortGetRunLoopSource(port)?.takeUnretainedValue() {
            CFRunLoopAddSource(CFRunLoopGetMain(), source, .commonModes)
        }

        let addedCallback: IOServiceMatchingCallback = { refcon, iterator in
            guard let refcon else {
                return
            }
            let monitor = Unmanaged<SystemEventMonitor>.fromOpaque(refcon).takeUnretainedValue()
            monitor.drain(iterator: iterator, reason: "usb-added")
        }

        let removedCallback: IOServiceMatchingCallback = { refcon, iterator in
            guard let refcon else {
                return
            }
            let monitor = Unmanaged<SystemEventMonitor>.fromOpaque(refcon).takeUnretainedValue()
            monitor.drain(iterator: iterator, reason: "usb-removed")
        }

        let context = UnsafeMutableRawPointer(Unmanaged.passUnretained(self).toOpaque())
        if let match = IOServiceMatching("IOUSBHostDevice") {
            IOServiceAddMatchingNotification(
                port,
                kIOFirstMatchNotification,
                match,
                addedCallback,
                context,
                &matchedIterator
            )
            drain(iterator: matchedIterator, reason: "usb-added")
        }
        if let match = IOServiceMatching("IOUSBHostDevice") {
            IOServiceAddMatchingNotification(
                port,
                kIOTerminatedNotification,
                match,
                removedCallback,
                context,
                &terminatedIterator
            )
            drain(iterator: terminatedIterator, reason: "usb-removed")
        }
    }

    private func startNetworkMonitoring() {
        guard dynamicStore == nil else {
            return
        }

        var context = SCDynamicStoreContext(
            version: 0,
            info: UnsafeMutableRawPointer(Unmanaged.passUnretained(self).toOpaque()),
            retain: nil,
            release: nil,
            copyDescription: nil
        )
        let callback: SCDynamicStoreCallBack = { _, _, info in
            guard let info else {
                return
            }
            let monitor = Unmanaged<SystemEventMonitor>.fromOpaque(info).takeUnretainedValue()
            monitor.emit("network")
        }

        guard let store = SCDynamicStoreCreate(nil, "RK356xToolkitGUI" as CFString, callback, &context) else {
            return
        }
        dynamicStore = store
        let patterns = [
            "State:/Network/Interface/.*/IPv4" as CFString,
            "State:/Network/Interface/.*/Link" as CFString,
            "State:/Network/Global/IPv4" as CFString,
        ] as CFArray
        SCDynamicStoreSetNotificationKeys(store, nil, patterns)
        if let source = SCDynamicStoreCreateRunLoopSource(nil, store, 0) {
            dynamicStoreSource = source
            CFRunLoopAddSource(CFRunLoopGetMain(), source, .commonModes)
        }
    }
}

@MainActor
final class ToolkitViewModel: ObservableObject {
    private let requiredServiceAPIVersion = 1
    private let preferredCLIName = "rk356xctl-swift"
    private let fallbackCLIName = "rk356xctl"
    private let servicePort = 17837
    private let releaseRepoRoot: String
    @Published var repoRoot: String
    @Published var workspaceMode: WorkspaceMode
    @Published var developmentRepoRoot: String?
    @Published var status: ToolkitStatus?
    @Published var serviceRunning = false
    @Published var busy = false
    @Published var lastError = ""
    @Published var lastActionSummary = "等待操作"
    @Published var activities: [ActivityEntry] = []
    @Published var logoPath = ""
    @Published var logoRotate = "-90"
    @Published var logoScale = "100"
    @Published var logoFlashAfter = true
    @Published var dtsFilePath = ""
    @Published var dtsFlashAfter = true
    @Published var localArtifactsDir = ""
    @Published var localArtifactValidation = LocalArtifactValidationState()
    @Published var inlineErrorMessage = ""
    @Published var footerFlashOn = false
    @Published var pendingTaskTitle = ""
    @Published var selectedActivityEntry: ActivityEntry?
    @Published var currentTask: ToolkitTask?
    @Published var fileDialogActive = false
    @Published var developmentInstallStatus = DevelopmentInstallStatus()
    @Published var installerLastDetail = "等待检查"
    @Published var toolkitUpdateStatus = ToolkitUpdateStatus()
    @Published var updaterLastDetail = "等待检查"
    @Published var automaticToolkitUpdateInProgress = false
    @Published var postFlashRecoveryActive = false
    @Published var postFlashRecoveryFinished = false
    @Published var postFlashRecoverySucceeded = false
    @Published var postFlashRecoveryTitle = "设备恢复"
    @Published var postFlashRecoveryStatus = ""
    @Published var postFlashRecoveryProgress = ""
    @Published var postFlashRecoveryProgressValue: Double?
    @Published var postFlashRecoveryLines: [String] = []

    private var didBootstrapService = false
    private var serviceStartInProgress = false
    private var lastRefreshErrorSignature = ""
    private var lastSnapshot: StatusSnapshot?
    private var eventTask: Task<Void, Never>?
    private var watchdogTask: Task<Void, Never>?
    private var transportMonitorTask: Task<Void, Never>?
    private var boardMonitorTask: Task<Void, Never>?
    private var hostMonitorTask: Task<Void, Never>?
    private var serviceMonitorTask: Task<Void, Never>?
    private var inlineErrorDismissTask: Task<Void, Never>?
    private var inlineErrorFlashTask: Task<Void, Never>?
    private var systemMonitor: SystemEventMonitor?
    private var pendingSystemRefreshTask: Task<Void, Never>?
    private var transitionWatchTask: Task<Void, Never>?
    private var taskPollTask: Task<Void, Never>?
    private var automaticToolkitUpdateTask: Task<Void, Never>?
    private var postFlashRecoveryTask: Task<Void, Never>?
    private var dismissedFinishedTaskIDs: Set<String> = []
    private var monitoringStarted = false
    private var lastEventAt = Date()
    private var lastIncompatibleServiceRecoveryAt: Date?
    private var refreshSequence = 0
    private var boardStateGraceUntil: Date?
    private var boardPingFalseCount = 0
    private var boardSSHFalseCount = 0
    private var boardControlFalseCount = 0
    private let boardFalseThreshold = 3
    private var shouldRelaunchAfterToolkitUpdate = false
    private var telemetrySessionID: String?
    init() {
        let release = Self.detectReleaseRepoRoot() ?? Self.detectRepoRoot() ?? ""
        let development = Self.detectDevelopmentRepoRoot(excluding: release)
        let savedMode = WorkspaceMode(rawValue: UserDefaults.standard.string(forKey: "workspaceMode") ?? "") ?? .release
        let initialMode: WorkspaceMode = (savedMode == .development && development != nil) ? .development : .release
        releaseRepoRoot = release
        developmentRepoRoot = development
        workspaceMode = initialMode
        repoRoot = Self.resolveRepoRoot(mode: initialMode, releaseRoot: release, developmentRoot: development)
        requestNotificationPermission()
    }

    static func detectRepoRoot() -> String? {
        let fm = FileManager.default
        let defaults = UserDefaults.standard.string(forKey: "repoRoot")
        let env = ProcessInfo.processInfo.environment["RK356X_TOOLKIT_REPO_ROOT"]
        let cwd = URL(fileURLWithPath: fm.currentDirectoryPath)
        let bundle = Bundle.main.bundleURL
        let resourceToolkit = Bundle.main.resourceURL?.appendingPathComponent("toolkit-runtime")

        var candidates: [URL] = []
        [defaults, env].compactMap { $0 }.forEach { candidates.append(URL(fileURLWithPath: $0)) }
        if let resourceToolkit {
            candidates.append(resourceToolkit)
        }

        var current = bundle
        for _ in 0..<8 {
            candidates.append(current)
            current.deleteLastPathComponent()
        }

        current = cwd
        for _ in 0..<8 {
            candidates.append(current)
            current.deleteLastPathComponent()
        }

        for candidate in candidates {
            let normalized = candidate.standardizedFileURL
            if Self.isValidRepoRoot(normalized.path) {
                return normalized.path
            }
            let nested = normalized.appendingPathComponent("docker_mac_env")
            if Self.isValidRepoRoot(nested.path) {
                return nested.path
            }
        }
        return nil
    }

    static func detectReleaseRepoRoot() -> String? {
        if let runtime = Bundle.main.resourceURL?.appendingPathComponent("toolkit-runtime"),
           isValidRepoRoot(runtime.path)
        {
            return runtime.standardizedFileURL.path
        }
        return detectRepoRoot()
    }

    static func detectDevelopmentRepoRoot(excluding releaseRoot: String) -> String? {
        let fm = FileManager.default
        let defaults = UserDefaults.standard.string(forKey: "developmentRepoRoot") ?? UserDefaults.standard.string(forKey: "repoRoot")
        let env = ProcessInfo.processInfo.environment["RK356X_TOOLKIT_DEV_ROOT"]
        let cwd = URL(fileURLWithPath: fm.currentDirectoryPath)
        let bundle = Bundle.main.bundleURL
        let releasePath = URL(fileURLWithPath: releaseRoot).standardizedFileURL.path

        var candidates: [URL] = []
        [defaults, env].compactMap { $0 }.forEach { candidates.append(URL(fileURLWithPath: $0)) }

        var current = bundle
        for _ in 0..<8 {
            candidates.append(current)
            current.deleteLastPathComponent()
        }

        current = cwd
        for _ in 0..<8 {
            candidates.append(current)
            current.deleteLastPathComponent()
        }

        for candidate in candidates {
            let normalized = candidate.standardizedFileURL
            for probe in [normalized, normalized.appendingPathComponent("docker_mac_env")] {
                let path = probe.standardizedFileURL.path
                guard path != releasePath else {
                    continue
                }
                if isValidRepoRoot(path) {
                    return path
                }
            }
        }
        return nil
    }

    static func resolveRepoRoot(mode: WorkspaceMode, releaseRoot: String, developmentRoot: String?) -> String {
        switch mode {
        case .release:
            return releaseRoot
        case .development:
            return developmentRoot ?? releaseRoot
        }
    }

    static func isValidRepoRoot(_ path: String) -> Bool {
        let url = URL(fileURLWithPath: path)
        return FileManager.default.fileExists(atPath: url.appendingPathComponent("rk356xctl-swift").path) ||
            FileManager.default.fileExists(atPath: url.appendingPathComponent("rk356xctl").path)
    }

    func requestNotificationPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { _, _ in }
    }

    deinit {
        eventTask?.cancel()
        watchdogTask?.cancel()
        transportMonitorTask?.cancel()
        boardMonitorTask?.cancel()
        hostMonitorTask?.cancel()
        serviceMonitorTask?.cancel()
        inlineErrorDismissTask?.cancel()
        inlineErrorFlashTask?.cancel()
        pendingSystemRefreshTask?.cancel()
        transitionWatchTask?.cancel()
        taskPollTask?.cancel()
        postFlashRecoveryTask?.cancel()
        systemMonitor?.stop()
    }

    func persistWorkspaceSelection() {
        UserDefaults.standard.set(workspaceMode.rawValue, forKey: "workspaceMode")
        if let developmentRepoRoot {
            UserDefaults.standard.set(developmentRepoRoot, forKey: "developmentRepoRoot")
        }
    }

    func workspaceURL() throws -> URL {
        guard !repoRoot.isEmpty else {
            throw ToolkitGUIError.repoRootNotFound
        }
        let url = URL(fileURLWithPath: repoRoot)
        guard Self.isValidRepoRoot(url.path) else {
            throw ToolkitGUIError.cliNotFound(url.appendingPathComponent(preferredCLIName).path)
        }
        return url
    }

    func cliURL() throws -> URL {
        let root = try workspaceURL()
        let preferred = root.appendingPathComponent(preferredCLIName)
        if FileManager.default.fileExists(atPath: preferred.path) {
            return preferred
        }
        return root.appendingPathComponent(fallbackCLIName)
    }

    var serviceBaseURL: URL {
        URL(string: "http://127.0.0.1:\(servicePort)")!
    }

    func appSupportRootURL() -> URL {
        (FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first?
            .appendingPathComponent("rk356x-mac-toolkit")) ?? URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("rk356x-mac-toolkit")
    }

    func hostImageDirURL() -> URL {
        if let override = ProcessInfo.processInfo.environment["HOST_IMAGE_DIR"], !override.isEmpty {
            return URL(fileURLWithPath: override)
        }
        let repoDefault = URL(fileURLWithPath: repoRoot).appendingPathComponent("../tspi-img").standardizedFileURL
        if FileManager.default.fileExists(atPath: repoDefault.path) {
            return repoDefault
        }
        return appSupportRootURL().appendingPathComponent("tspi-img", isDirectory: true)
    }

    var officialImageName: String { "tspi-rk356x-env" }
    var officialContainerName: String { "tspi-rk356x-official-container" }
    var officialVolumeName: String { "tspi-rk356x-official-workspace" }
    var developmentContainerName: String { "rk-sdk-container" }
    var developmentVolumeName: String { "rk-sdk-workspace" }

    var activeContainerName: String {
        workspaceMode == .release ? officialContainerName : developmentContainerName
    }

    var activeVolumeName: String {
        workspaceMode == .release ? officialVolumeName : developmentVolumeName
    }

    var activeImageName: String {
        officialImageName
    }

    func workspaceRuntimeEnvironment() -> [String: String] {
        [
            "IMAGE_NAME": activeImageName,
            "CONTAINER_NAME": activeContainerName,
            "VOLUME_NAME": activeVolumeName,
        ]
    }

    func bundledRuntimeIsActive() -> Bool {
        guard !releaseRepoRoot.isEmpty else {
            return false
        }
        return URL(fileURLWithPath: releaseRepoRoot).standardizedFileURL.path ==
            URL(fileURLWithPath: repoRoot).standardizedFileURL.path
    }

    func runCLI(_ arguments: [String]) async throws -> (Int32, String) {
        let executableURL = try cliURL()
        let currentDirectoryURL = try workspaceURL()

        var env = ProcessInfo.processInfo.environment
        for (key, value) in workspaceRuntimeEnvironment() {
            env[key] = value
        }
        if bundledRuntimeIsActive() {
            let supportRoot = (FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first?
                .appendingPathComponent("rk356x-mac-toolkit")) ?? URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("rk356x-mac-toolkit")
            let stateDir = supportRoot.appendingPathComponent("state")
            let imageDir = supportRoot.appendingPathComponent("tspi-img")
            env["RK356X_TOOLKIT_APP_SUPPORT_DIR"] = supportRoot.path
            env["RK356X_TOOLKIT_STATE_DIR"] = stateDir.path
            env["HOST_IMAGE_DIR"] = imageDir.path
        }
        return try await ProcessExecutor.run(
            executableURL: executableURL,
            arguments: arguments,
            currentDirectoryURL: currentDirectoryURL,
            environment: env
        )
    }

    func shellEnvironment() throws -> [String: String] {
        var env = ProcessInfo.processInfo.environment
        env["PROJECT_ROOT"] = try workspaceURL().path
        env["HOST_IMAGE_DIR"] = hostImageDirURL().path
        for (key, value) in workspaceRuntimeEnvironment() {
            env[key] = value
        }
        if bundledRuntimeIsActive() {
            let supportRoot = appSupportRootURL()
            env["RK356X_TOOLKIT_APP_SUPPORT_DIR"] = supportRoot.path
            env["RK356X_TOOLKIT_STATE_DIR"] = supportRoot.appendingPathComponent("state").path
            env["HOST_IMAGE_DIR"] = supportRoot.appendingPathComponent("tspi-img").path
        }
        return env
    }

    func runShell(_ script: String) async throws -> (Int32, String) {
        try await ProcessExecutor.run(
            executableURL: URL(fileURLWithPath: "/bin/bash"),
            arguments: ["-lc", script],
            currentDirectoryURL: try workspaceURL(),
            environment: try shellEnvironment()
        )
    }

    func extractJSONObject(_ text: String) -> String? {
        guard let start = text.firstIndex(of: "{"), let end = text.lastIndex(of: "}") else {
            return nil
        }
        return String(text[start...end])
    }

    func runStatusCLI(_ arguments: [String]) async throws -> ToolkitStatus {
        let (code, output) = try await runCLI(arguments)
        guard code == 0 else {
            throw ToolkitGUIError.commandFailed(output)
        }
        guard let jsonText = extractJSONObject(output) else {
            throw ToolkitGUIError.invalidJSON(output)
        }
        let data = Data(jsonText.utf8)
        if let status = try? JSONDecoder().decode(ToolkitStatus.self, from: data) {
            return status
        }
        let envelope = try JSONDecoder().decode(StatusEnvelope.self, from: data)
        guard let state = envelope.state else {
            throw ToolkitGUIError.invalidJSON(output)
        }
        return state
    }

    func runTransportCLI() async throws -> TransportStatusResponse {
        let (code, output) = try await runCLI(["transport-status", "--json"])
        guard code == 0 else {
            throw ToolkitGUIError.commandFailed(output)
        }
        guard let jsonText = extractJSONObject(output) else {
            throw ToolkitGUIError.invalidJSON(output)
        }
        return try JSONDecoder().decode(TransportStatusResponse.self, from: Data(jsonText.utf8))
    }

    func runBoardCLI() async throws -> BoardStatusResponse {
        let (code, output) = try await runCLI(["board-status", "--json"])
        guard code == 0 else {
            throw ToolkitGUIError.commandFailed(output)
        }
        guard let jsonText = extractJSONObject(output) else {
            throw ToolkitGUIError.invalidJSON(output)
        }
        return try JSONDecoder().decode(BoardStatusResponse.self, from: Data(jsonText.utf8))
    }

    func runHostCLI() async throws -> HostStatusResponse {
        let (code, output) = try await runCLI(["host-status", "--json"])
        guard code == 0 else {
            throw ToolkitGUIError.commandFailed(output)
        }
        guard let jsonText = extractJSONObject(output) else {
            throw ToolkitGUIError.invalidJSON(output)
        }
        return try JSONDecoder().decode(HostStatusResponse.self, from: Data(jsonText.utf8))
    }

    func runJSONAction(_ arguments: [String]) async throws -> ActionResponse {
        let (code, output) = try await runCLI(arguments)
        guard let jsonText = extractJSONObject(output) else {
            throw ToolkitGUIError.invalidJSON(output)
        }
        let data = Data(jsonText.utf8)
        let response = try JSONDecoder().decode(ActionResponse.self, from: data)
        if code != 0 || response.ok == false {
            throw ToolkitGUIError.commandFailed(response.error ?? output)
        }
        return response
    }

    func serviceArgs(_ base: [String]) -> [String] {
        var args = base.filter { $0 != "--service" }
        args.append("--service")
        if !args.contains("--port") {
            args.append(contentsOf: ["--port", String(servicePort)])
        }
        return args
    }

    func serviceURL(path: String) -> URL {
        serviceBaseURL.appendingPathComponent(path)
    }

    func fetchServiceStatus() async throws -> ToolkitStatus {
        var request = URLRequest(url: serviceURL(path: "api/status"))
        request.timeoutInterval = 6
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            throw ToolkitGUIError.commandFailed("本地服务状态请求失败")
        }
        let envelope = try JSONDecoder().decode(StatusEnvelope.self, from: data)
        guard let state = envelope.state else {
            throw ToolkitGUIError.invalidJSON(String(decoding: data, as: UTF8.self))
        }
        serviceRunning = true
        return state
    }

    func fetchServiceTask(_ taskID: String) async throws -> ToolkitTask {
        var request = URLRequest(url: serviceURL(path: "api/tasks/\(taskID)"))
        request.timeoutInterval = 6
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw ToolkitGUIError.commandFailed("任务状态请求失败")
        }
        let envelope = try JSONDecoder().decode(TaskResponse.self, from: data)
        if http.statusCode != 200 || envelope.ok == false || envelope.task == nil {
            throw ToolkitGUIError.commandFailed(envelope.error ?? "任务状态请求失败")
        }
        guard let task = envelope.task else {
            throw ToolkitGUIError.commandFailed("任务状态缺失")
        }
        serviceRunning = true
        return task
    }

    func postServiceAction(action: String, payload: [String: Any], async: Bool) async throws -> RunActionServiceResponse {
        var request = URLRequest(url: serviceURL(path: "api/run"))
        request.httpMethod = "POST"
        request.timeoutInterval = async ? 10 : 600
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(
            withJSONObject: [
                "action": action,
                "payload": payload,
                "async": async,
            ],
            options: []
        )
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw ToolkitGUIError.commandFailed("本地服务执行失败")
        }
        if http.statusCode != 200 {
            let errorEnvelope = try? JSONDecoder().decode(ActionResponse.self, from: data)
            throw ToolkitGUIError.commandFailed(errorEnvelope?.error ?? String(decoding: data, as: UTF8.self))
        }
        let decoded = try JSONDecoder().decode(RunActionServiceResponse.self, from: data)
        if decoded.ok == false {
            throw ToolkitGUIError.commandFailed(decoded.error ?? "本地服务执行失败")
        }
        serviceRunning = true
        return decoded
    }

    func runPlainAction(_ arguments: [String]) async throws -> String {
        let (code, output) = try await runCLI(arguments)
        guard code == 0 else {
            throw ToolkitGUIError.commandFailed(output)
        }
        return output
    }

    func runWithTimeout<T>(
        seconds: Double,
        failureMessage: String,
        operation: @escaping () async throws -> T
    ) async throws -> T {
        try await withThrowingTaskGroup(of: T.self) { group in
            group.addTask { @MainActor in
                try await operation()
            }
            group.addTask {
                try await Task.sleep(for: .seconds(seconds))
                throw ToolkitGUIError.timeout(failureMessage)
            }
            let result = try await group.next()!
            group.cancelAll()
            return result
        }
    }

    func runTaskAction(_ arguments: [String]) async throws -> TaskResponse {
        let (code, output) = try await runCLI(arguments)
        guard let jsonText = extractJSONObject(output) else {
            throw ToolkitGUIError.invalidJSON(output)
        }
        let data = Data(jsonText.utf8)
        let response = try JSONDecoder().decode(TaskResponse.self, from: data)
        if code != 0 || response.ok == false {
            throw ToolkitGUIError.commandFailed(response.error ?? output)
        }
        return response
    }

    func runTelemetryCommand(_ arguments: [String]) async throws -> TelemetrySessionCommandResponse {
        let (code, output) = try await runCLI(arguments)
        guard let jsonText = extractJSONObject(output) else {
            throw ToolkitGUIError.invalidJSON(output)
        }
        let response = try JSONDecoder().decode(TelemetrySessionCommandResponse.self, from: Data(jsonText.utf8))
        if code != 0 || response.ok == false {
            throw ToolkitGUIError.commandFailed(response.error ?? output)
        }
        return response
    }

    func runTelemetryCommandSync(_ arguments: [String]) throws -> TelemetrySessionCommandResponse {
        let executableURL = try cliURL()
        let currentDirectoryURL = try workspaceURL()

        var env = ProcessInfo.processInfo.environment
        for (key, value) in workspaceRuntimeEnvironment() {
            env[key] = value
        }
        if bundledRuntimeIsActive() {
            let supportRoot = appSupportRootURL()
            env["RK356X_TOOLKIT_APP_SUPPORT_DIR"] = supportRoot.path
            env["RK356X_TOOLKIT_STATE_DIR"] = supportRoot.appendingPathComponent("state").path
            env["HOST_IMAGE_DIR"] = supportRoot.appendingPathComponent("tspi-img").path
        }

        let (code, output) = try ProcessExecutor.runSync(
            executableURL: executableURL,
            arguments: arguments,
            currentDirectoryURL: currentDirectoryURL,
            environment: env
        )
        guard let jsonText = extractJSONObject(output) else {
            throw ToolkitGUIError.invalidJSON(output)
        }
        let response = try JSONDecoder().decode(TelemetrySessionCommandResponse.self, from: Data(jsonText.utf8))
        if code != 0 || response.ok == false {
            throw ToolkitGUIError.commandFailed(response.error ?? output)
        }
        return response
    }

    func startGUITelemetrySession() {
        Task { @MainActor in
            guard telemetrySessionID == nil else {
                return
            }
            do {
                let response = try await runTelemetryCommand(["telemetry", "session-start", "--source", "gui", "--json"])
                telemetrySessionID = response.session_id
            } catch {
                appendActivity(level: .warning, title: "使用统计", message: "GUI 会话采集启动失败", detail: error.localizedDescription)
            }
        }
    }

    func stopGUITelemetrySessionSync(reason: String) {
        guard let sessionID = telemetrySessionID else {
            return
        }
        defer { telemetrySessionID = nil }
        do {
            _ = try runTelemetryCommandSync(["telemetry", "session-stop", "--session-id", sessionID, "--reason", reason, "--json"])
        } catch {
            appendActivity(level: .warning, title: "使用统计", message: "GUI 会话采集结束失败", detail: error.localizedDescription)
        }
    }

    func placeholderStatus() -> ToolkitStatus {
        ToolkitStatus(
            repo_root: repoRoot.isEmpty ? nil : repoRoot,
            service: status?.service,
            updated_at: ISO8601DateFormatter().string(from: Date()),
            usb: status?.usb ?? .init(mode: "absent", product: nil, pid: nil),
            usbnet: status?.usbnet ?? .init(iface: nil, current_ip: nil, expected_ip: "198.19.77.2", configured: false),
            board: status?.board ?? .init(ping: false, ssh_port_open: false, control_service: false),
            host: status?.host
        )
    }

    func mergedStatus(
        usb: ToolkitStatus.USB? = nil,
        usbnet: ToolkitStatus.USBNet? = nil,
        board: ToolkitStatus.Board? = nil,
        host: ToolkitStatus.Host? = nil,
        updatedAt: String? = nil
    ) -> ToolkitStatus {
        let current = status ?? placeholderStatus()
        return ToolkitStatus(
            repo_root: current.repo_root ?? repoRoot,
            service: current.service,
            updated_at: updatedAt ?? ISO8601DateFormatter().string(from: Date()),
            usb: usb ?? current.usb,
            usbnet: usbnet ?? current.usbnet,
            board: board ?? current.board,
            host: host ?? current.host
        )
    }

    func resolvedImagePath(for target: String) -> URL? {
        let imageDir = hostImageDirURL()
        switch target {
        case "rootfs":
            let img = imageDir.appendingPathComponent("rootfs.img")
            if FileManager.default.fileExists(atPath: img.path) {
                return img
            }
            let ext4 = imageDir.appendingPathComponent("rootfs.ext4")
            if FileManager.default.fileExists(atPath: ext4.path) {
                return ext4
            }
            return nil
        case "all":
            return nil
        default:
            let image = imageDir.appendingPathComponent("\(target).img")
            return FileManager.default.fileExists(atPath: image.path) ? image : nil
        }
    }

    func hasAnyFlashableImage() -> Bool {
        let imageDir = hostImageDirURL()
        let candidates = [
            "boot.img",
            "rootfs.img",
            "rootfs.ext4",
            "userdata.img",
            "oem.img",
            "recovery.img",
            "uboot.img",
            "update.img",
        ]
        return candidates.contains { FileManager.default.fileExists(atPath: imageDir.appendingPathComponent($0).path) }
    }

    func refreshDevelopmentInstallStatus() async {
        do {
            let hostResponse = try await runHostCLI()
            let host = hostResponse.host
            var next = DevelopmentInstallStatus()
            next.dockerReady = host?.docker_daemon == true
            next.officialImageReady = host?.official_image == true
            next.rkflashtoolReady = host?.rkflashtool_built == true
            next.updatedAt = hostResponse.updated_at ?? ISO8601DateFormatter().string(from: Date())

            let imageDir = hostImageDirURL()
            let requiredHostImages = [
                imageDir.appendingPathComponent("parameter.txt").path,
                imageDir.appendingPathComponent("boot.img").path,
                imageDir.appendingPathComponent("userdata.img").path,
            ]
            next.hostImagesReady = requiredHostImages.allSatisfy { FileManager.default.fileExists(atPath: $0) }

            if next.dockerReady {
                let volumeCheck = try await runShell("docker volume inspect '\(officialVolumeName)' >/dev/null 2>&1")
                next.releaseVolumeReady = volumeCheck.0 == 0
            }

            let home = NSHomeDirectory()
            let codexCandidates = [
                "\(home)/.codex/.tmp/plugins/plugins/rk356x-mac-toolkit/.codex-plugin/plugin.json",
                "\(home)/plugins/rk356x-mac-toolkit/.codex-plugin/plugin.json"
            ]
            next.codexAvailable = FileManager.default.fileExists(atPath: "\(home)/.codex")
            next.codexPluginInstalled = codexCandidates.contains { FileManager.default.fileExists(atPath: $0) }

            let opencodeCandidates = [
                "\(home)/.config/opencode/plugins/rk356x-toolkit.js",
                "\(home)/.config/opencode/plugins/rk356x-toolkit.runtime.json"
            ]
            let npmCheck = try await runShell("command -v npm >/dev/null 2>&1")
            next.npmReady = npmCheck.0 == 0
            let opencodeCheck = try await runShell("command -v opencode >/dev/null 2>&1")
            next.openCodeAvailable = opencodeCheck.0 == 0 || FileManager.default.fileExists(atPath: "\(home)/.config/opencode")
            next.openCodePluginInstalled = opencodeCandidates.allSatisfy { FileManager.default.fileExists(atPath: $0) }

            developmentInstallStatus = next
        } catch {
            installerLastDetail = "环境状态刷新失败：\(error.localizedDescription)"
        }
    }

    func currentToolkitVersion() -> String {
        if let bundleVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String,
           !bundleVersion.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        {
            return bundleVersion.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        let versionURL = URL(fileURLWithPath: repoRoot).appendingPathComponent("VERSION")
        if let version = try? String(contentsOf: versionURL, encoding: .utf8)
            .trimmingCharacters(in: .whitespacesAndNewlines),
           !version.isEmpty
        {
            return version
        }
        return "unknown"
    }

    func refreshToolkitUpdateStatus() {
        var next = toolkitUpdateStatus
        next.currentVersion = currentToolkitVersion()
        let distributionURL = URL(fileURLWithPath: repoRoot).appendingPathComponent("product_release/release-installer/distribution.env")
        if let text = try? String(contentsOf: distributionURL, encoding: .utf8) {
            let lines = text
                .split(separator: "\n")
                .map(String.init)
                .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            next.configured = lines.contains { line in
                (line.hasPrefix("RK356X_REMOTE_TOOLKIT_MANIFEST_URL=") ||
                 line.hasPrefix("RK356X_REMOTE_BASE_URL=") ||
                 line.hasPrefix("RK356X_REMOTE_UPDATE_MANIFEST_URL=") ||
                 line.hasPrefix("RK356X_REMOTE_TOOLKIT_BUNDLE_URL=")) &&
                    !line.hasSuffix("\"\"")
            }
        } else {
            next.configured = false
        }
        if !next.configured {
            next.remoteVersion = ""
            next.updateAvailable = false
        }
        toolkitUpdateStatus = next
    }

    func parseUpdateStatus(detail: String) {
        var next = toolkitUpdateStatus
        next.currentVersion = currentToolkitVersion()
        next.configured = !detail.contains("not configured") && !detail.contains("Toolkit bundle URL is not configured")
        for raw in detail.split(separator: "\n").map(String.init) {
            let line = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            if line.contains("local version:") {
                next.currentVersion = line.components(separatedBy: "local version:").last?.trimmingCharacters(in: .whitespacesAndNewlines) ?? next.currentVersion
            } else if line.contains("remote version:") {
                next.remoteVersion = line.components(separatedBy: "remote version:").last?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            } else if line.contains("update available") {
                next.updateAvailable = true
            } else if line.contains("already up to date") {
                next.updateAvailable = false
            }
        }
        next.checkedAt = ISO8601DateFormatter().string(from: Date())
        toolkitUpdateStatus = next
    }

    func validatePrecondition(_ precondition: ActionPrecondition) async -> String? {
        switch precondition {
        case .checkHost:
            await refreshHostStatus(silent: true)
            return nil

        case .ensureUSBNet:
            await refreshTransportStatus(silent: true)
            guard status?.usb?.mode == "usb-ecm" else {
                return "当前未检测到 USB ECM 连接，无法恢复主机静态地址。"
            }
            return nil

        case .authorizeKey, .rebootLoader:
            await refreshTransportStatus(silent: true)
            guard status?.usb?.mode == "usb-ecm" else {
                return "当前未检测到 USB ECM 连接。"
            }
            guard status?.usbnet?.configured == true else {
                return "主机 USB 网络尚未配置完成，请先恢复到 198.19.77.2。"
            }
            await refreshBoardStatus(silent: true)
            guard status?.board?.control_service == true else {
                return "开发板控制服务未响应，当前无法执行该操作。"
            }
            return nil

        case .rebootDevice:
            await refreshTransportStatus(silent: true)
            guard status?.usb?.mode == "usb-ecm" else {
                return "当前未检测到 USB ECM 连接。"
            }
            guard status?.usbnet?.configured == true else {
                return "主机 USB 网络尚未配置完成，请先恢复到 198.19.77.2。"
            }
            await refreshBoardStatus(silent: true)
            let controlReady = status?.board?.control_service == true
            let sshReady = status?.board?.ssh_port_open == true
            guard controlReady || sshReady else {
                return "开发板控制服务和 SSH 都不可用，当前无法执行设备重启。"
            }
            return nil

        case let .flash(target):
            await refreshTransportStatus(silent: true)
            guard status?.usb?.mode != nil, status?.usb?.mode != "absent" else {
                return "未检测到开发板 USB 连接，无法开始刷写。"
            }
            let imageDir = hostImageDirURL()
            let parameter = imageDir.appendingPathComponent("parameter.txt")
            guard FileManager.default.fileExists(atPath: parameter.path) else {
                return "未找到 parameter.txt：\(parameter.path)"
            }
            if target == "all" {
                guard hasAnyFlashableImage() else {
                    return "镜像目录中没有可刷写的镜像文件：\(imageDir.path)"
                }
            } else {
                guard let imagePath = resolvedImagePath(for: target) else {
                    return "未找到 \(target) 对应镜像文件，期望目录：\(imageDir.path)"
                }
                guard FileManager.default.fileExists(atPath: imagePath.path) else {
                    return "镜像文件不存在：\(imagePath.path)"
                }
            }
            return nil

        case .buildSync:
            await refreshHostStatus(silent: true)
            guard status?.host?.docker_daemon == true else {
                return "Docker 未就绪，无法执行构建同步。"
            }
            return nil

        case .buildSyncFlash:
            await refreshHostStatus(silent: true)
            guard status?.host?.docker_daemon == true else {
                return "Docker 未就绪，无法执行构建同步刷写。"
            }
            await refreshTransportStatus(silent: true)
            guard status?.usb?.mode != nil, status?.usb?.mode != "absent" else {
                return "未检测到开发板 USB 连接，无法执行刷写。"
            }
            return nil

        case let .updateLogo(flashAfter):
            await refreshHostStatus(silent: true)
            guard status?.host?.docker_daemon == true else {
                return "Docker 未就绪，无法更新启动 Logo。"
            }
            guard !logoPath.isEmpty, FileManager.default.fileExists(atPath: logoPath) else {
                return "请选择存在的启动 Logo 文件。"
            }
            guard let scale = Int(logoScale), (1...100).contains(scale) else {
                return "Logo 显示比例必须是 1 到 100 之间的整数。"
            }
            if flashAfter {
                return await validatePrecondition(.flash("boot"))
            }
            return nil

        case let .updateDTB(flashAfter):
            await refreshHostStatus(silent: true)
            guard status?.host?.docker_daemon == true else {
                return "Docker 未就绪，无法更新设备树。"
            }
            guard !dtsFilePath.isEmpty, FileManager.default.fileExists(atPath: dtsFilePath) else {
                return "请选择存在的设备树文件。"
            }
            if flashAfter {
                return await validatePrecondition(.flash("boot"))
            }
            return nil
        }
    }

    func refreshServiceState() async {
        do {
            let serviceStatus = try await fetchServiceStatus()
            let apiVersion = serviceStatus.service?.api_version ?? 0
            if apiVersion < requiredServiceAPIVersion {
                await recoverFromIncompatibleService()
                serviceRunning = false
                return
            }
            serviceRunning = true
        } catch {
            serviceRunning = false
        }
    }

    func refreshTransportStatus(silent: Bool = true) async {
        do {
            let response = try await runTransportCLI()
            let nextUSB = response.usb ?? ToolkitStatus.USB(mode: "absent", product: nil, pid: nil)
            let nextUSBNet = response.usbnet ?? ToolkitStatus.USBNet(iface: nil, current_ip: nil, expected_ip: "198.19.77.2", configured: false)
            let connected = nextUSB.mode == "usb-ecm" && nextUSBNet.configured == true
            let nextBoard = connected ? nil : ToolkitStatus.Board(ping: false, ssh_port_open: false, control_service: false)
            let merged = mergedStatus(usb: nextUSB, usbnet: nextUSBNet, board: nextBoard, updatedAt: response.updated_at)
            applyStatusUpdate(merged, silent: silent)
            if connected {
                ensureBoardMonitoring(forceImmediate: true)
            } else {
                stopBoardMonitoring()
            }
        } catch {
            if !silent {
                presentInlineError("刷新连接状态失败: \(error.localizedDescription)")
            }
        }
    }

    func refreshBoardStatus(silent: Bool = true) async {
        guard status?.usb?.mode == "usb-ecm", status?.usbnet?.configured == true else {
            resetBoardFailureCounters()
            let merged = mergedStatus(board: .init(ping: false, ssh_port_open: false, control_service: false))
            applyStatusUpdate(merged, silent: true)
            return
        }
        do {
            let response = try await runBoardCLI()
            let stableBoard = stabilizedBoardStatus(response.board)
            let merged = mergedStatus(board: stableBoard, updatedAt: response.updated_at)
            applyStatusUpdate(merged, silent: silent)
        } catch {
            if !silent {
                presentInlineError("刷新板卡状态失败: \(error.localizedDescription)")
            }
        }
    }

    func refreshHostStatus(silent: Bool = true) async {
        do {
            let response = try await runHostCLI()
            let merged = mergedStatus(host: response.host, updatedAt: response.updated_at)
            applyStatusUpdate(merged, silent: silent)
        } catch {
            if !silent {
                presentInlineError("刷新主机状态失败: \(error.localizedDescription)")
            }
        }
    }

    func startTransportMonitor() {
        transportMonitorTask?.cancel()
        transportMonitorTask = Task { [weak self] in
            guard let self else { return }
            while !Task.isCancelled {
                if !self.isFlashTaskRunning {
                    await self.refreshTransportStatus(silent: true)
                }
                try? await Task.sleep(for: .seconds(1))
            }
        }
    }

    func ensureBoardMonitoring(forceImmediate: Bool = false) {
        if forceImmediate {
            Task { [weak self] in
                await self?.refreshBoardStatus(silent: true)
            }
        }
        guard boardMonitorTask == nil || boardMonitorTask?.isCancelled == true else {
            return
        }
        boardMonitorTask = Task { [weak self] in
            guard let self else { return }
            let started = Date()
            while !Task.isCancelled {
                guard self.status?.usb?.mode == "usb-ecm", self.status?.usbnet?.configured == true else {
                    self.boardMonitorTask = nil
                    return
                }
                await self.refreshBoardStatus(silent: true)
                let elapsed = Date().timeIntervalSince(started)
                let interval: Duration = elapsed < 12 ? .milliseconds(600) : .seconds(2)
                try? await Task.sleep(for: interval)
            }
            self.boardMonitorTask = nil
        }
    }

    func stopBoardMonitoring() {
        boardMonitorTask?.cancel()
        boardMonitorTask = nil
    }

    func startHostMonitor() {
        hostMonitorTask?.cancel()
        hostMonitorTask = Task { [weak self] in
            guard let self else { return }
            while !Task.isCancelled {
                if !self.isFlashTaskRunning {
                    await self.refreshHostStatus(silent: true)
                }
                try? await Task.sleep(for: .seconds(12))
            }
        }
    }

    func startServiceMonitor() {
        serviceMonitorTask?.cancel()
        serviceMonitorTask = Task { [weak self] in
            guard let self else { return }
            while !Task.isCancelled {
                await self.refreshServiceState()
                try? await Task.sleep(for: .seconds(2))
            }
        }
    }

    func appendActivity(level: ActivityLevel, title: String, message: String, detail: String? = nil) {
        let entry = ActivityEntry(level: level, title: title, message: message, detail: detail)
        activities.insert(entry, at: 0)
        if activities.count > 50 {
            activities.removeLast(activities.count - 50)
        }
        lastActionSummary = "\(title): \(message)"
    }

    func presentInlineError(_ message: String) {
        lastError = message
        inlineErrorMessage = message
        footerFlashOn = true
        inlineErrorDismissTask?.cancel()
        inlineErrorFlashTask?.cancel()
        inlineErrorFlashTask = Task { [weak self] in
            guard let self else { return }
            for index in 0..<4 {
                guard !Task.isCancelled, self.inlineErrorMessage == message else { return }
                self.footerFlashOn = index % 2 == 0
                try? await Task.sleep(for: .milliseconds(220))
            }
            if !Task.isCancelled, self.inlineErrorMessage == message {
                self.footerFlashOn = false
            }
        }
        inlineErrorDismissTask = Task { [weak self] in
            try? await Task.sleep(for: .seconds(2))
            guard let self, !Task.isCancelled, self.inlineErrorMessage == message else {
                return
            }
            self.clearInlineError()
        }
    }

    func clearInlineError() {
        inlineErrorDismissTask?.cancel()
        inlineErrorFlashTask?.cancel()
        inlineErrorMessage = ""
        lastError = ""
        footerFlashOn = false
    }

    func dismissCurrentTaskOverlay() {
        if postFlashRecoveryActive, postFlashRecoveryFinished {
            clearPostFlashRecovery()
        }
        if currentTask?.status == "finished" {
            if let taskID = currentTask?.id {
                dismissedFinishedTaskIDs.insert(taskID)
            }
            currentTask = nil
        }
        pendingTaskTitle = ""
    }

    var isFlashTaskRunning: Bool {
        if postFlashRecoveryActive && !postFlashRecoveryFinished {
            return true
        }
        if pendingTaskTitle.contains("刷写") {
            return true
        }
        guard let task = currentTask else {
            return false
        }
        return task.action == "flash" && task.status != "finished"
    }

    func pollTask(_ taskID: String) {
        taskPollTask?.cancel()
        taskPollTask = Task { [weak self] in
            guard let self else {
                return
            }
            while !Task.isCancelled {
                do {
                    if serviceRunning {
                        let task = try await fetchServiceTask(taskID)
                        handleTaskUpdate(task)
                        if task.status == "finished" {
                            return
                        }
                    } else {
                        let response = try await runTaskAction(["task-status", taskID, "--json"])
                        if let task = response.task {
                            handleTaskUpdate(task)
                            if task.status == "finished" {
                                return
                            }
                        }
                    }
                } catch {
                    presentInlineError(error.localizedDescription)
                    return
                }
                try? await Task.sleep(for: .seconds(1))
            }
        }
    }

    func sendUserNotification(title: String, message: String) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = message
        content.sound = .default
        let request = UNNotificationRequest(
            identifier: UUID().uuidString,
            content: content,
            trigger: nil
        )
        UNUserNotificationCenter.current().add(request)
    }

    func handleTaskUpdate(_ task: ToolkitTask) {
        if task.status == "finished", let taskID = task.id, dismissedFinishedTaskIDs.contains(taskID) {
            return
        }
        currentTask = task
        if isInstallerTask(task), let output = task.output_tail, !output.isEmpty {
            installerLastDetail = output
        } else if isInstallerTask(task), task.status != "finished" {
            installerLastDetail = taskProgressLine(for: task)
        }
        if isUpdaterTask(task), let output = task.output_tail, !output.isEmpty {
            updaterLastDetail = output
        } else if isUpdaterTask(task), task.status != "finished" {
            updaterLastDetail = taskProgressLine(for: task)
        }
        guard task.status == "finished" else {
            return
        }
        taskPollTask?.cancel()
        pendingTaskTitle = ""
        if task.ok == true {
            if isInstallerTask(task) {
                installerLastDetail = task.action == "release-build-image" ? "官方镜像安装完成" : "发布环境安装任务已完成"
            }
            if isUpdaterTask(task) {
                if task.action == "release-update-images" {
                    updaterLastDetail = "初始镜像更新完成，可直接用于恢复刷写。"
                } else {
                    updaterLastDetail = shouldRelaunchAfterToolkitUpdate ? "更新完成，正在重启应用..." : "更新完成"
                    var next = toolkitUpdateStatus
                    next.updateAvailable = false
                    toolkitUpdateStatus = next
                    if shouldRelaunchAfterToolkitUpdate {
                        shouldRelaunchAfterToolkitUpdate = false
                        relaunchToolkitApplication()
                    }
                }
            }
            appendActivity(level: .success, title: task.action ?? "任务", message: "已完成", detail: task.output_tail)
            sendUserNotification(title: task.action ?? "任务", message: "已完成")
            if task.action == "flash" {
                startPostFlashRecovery(.flash)
            }
            let finishedTaskID = task.id
            Task { @MainActor [weak self] in
                try? await Task.sleep(for: .seconds(3))
                guard let self else {
                    return
                }
                if self.currentTask?.id == finishedTaskID {
                    if let finishedTaskID {
                        self.dismissedFinishedTaskIDs.insert(finishedTaskID)
                    }
                    self.currentTask = nil
                }
            }
        } else {
            let detail = task.output_tail ?? "任务执行失败"
            if isInstallerTask(task) {
                installerLastDetail = detail
            }
            if isUpdaterTask(task) {
                shouldRelaunchAfterToolkitUpdate = false
                updaterLastDetail = detail
            }
            presentInlineError(detail)
            appendActivity(level: .error, title: task.action ?? "任务", message: "执行失败", detail: detail)
            sendUserNotification(title: task.action ?? "任务", message: "执行失败")
        }
        refreshStatus(silent: true)
        Task {
            await refreshDevelopmentInstallStatus()
        }
        refreshToolkitUpdateStatus()
    }

    func clearPostFlashRecovery() {
        postFlashRecoveryTask?.cancel()
        postFlashRecoveryActive = false
        postFlashRecoveryFinished = false
        postFlashRecoverySucceeded = false
        postFlashRecoveryTitle = "设备恢复"
        postFlashRecoveryStatus = ""
        postFlashRecoveryProgress = ""
        postFlashRecoveryProgressValue = nil
        postFlashRecoveryLines = []
    }

    func updatePostFlashRecovery(
        status: String,
        progress: String,
        progressValue: Double?,
        line: String? = nil,
        finished: Bool = false,
        succeeded: Bool = false
    ) {
        postFlashRecoveryActive = true
        postFlashRecoveryStatus = status
        postFlashRecoveryProgress = progress
        postFlashRecoveryProgressValue = progressValue
        postFlashRecoveryFinished = finished
        postFlashRecoverySucceeded = succeeded
        if let line, !line.isEmpty {
            if postFlashRecoveryLines.last != line {
                postFlashRecoveryLines.append(line)
            }
            if postFlashRecoveryLines.count > 6 {
                postFlashRecoveryLines.removeFirst(postFlashRecoveryLines.count - 6)
            }
        }
    }

    func startPostFlashRecovery(_ context: DeviceRecoveryContext = .flash) {
        postFlashRecoveryTask?.cancel()
        postFlashRecoveryTitle = context.activityTitle
        appendActivity(level: .info, title: context.activityTitle, message: "等待设备重启并恢复 USB ECM 网络")
        updatePostFlashRecovery(
            status: context == .flash ? "刷写完成，等待设备重启" : "设备重启中，等待重新连接",
            progress: "正在等待设备重启并重新枚举为 USB ECM…",
            progressValue: 0.2,
            line: context.initialLine
        )
        postFlashRecoveryTask = Task { [weak self] in
            guard let self else { return }
            let rebootDeadline = Date().addingTimeInterval(45)
            while !Task.isCancelled, Date() < rebootDeadline {
                await self.refreshTransportStatus(silent: true)
                if self.status?.usb?.mode == "usb-ecm" {
                    self.updatePostFlashRecovery(
                        status: "设备已重启，正在恢复 USB 网络",
                        progress: "检测到 USB ECM，正在恢复主机地址 198.19.77.2…",
                        progressValue: 0.7,
                        line: "检测到设备已回到 USB ECM"
                    )
                    var ensureSucceeded = false
                    var lastEnsureError = ""
                    let ensureDeadline = Date().addingTimeInterval(12)
                    while !Task.isCancelled, Date() < ensureDeadline {
                        do {
                            let response = try await self.runJSONAction(["usbnet", "ensure", "--json"])
                            self.appendActivity(
                                level: .success,
                                title: context.activityTitle,
                                message: "主机 USB 网络已恢复",
                                detail: response.output
                            )
                            self.updatePostFlashRecovery(
                                status: "设备已恢复在线",
                                progress: "主机 USB 网络已恢复，正在确认板卡状态…",
                                progressValue: 0.9,
                                line: response.output ?? "主机 USB 网络已恢复"
                            )
                            ensureSucceeded = true
                            break
                        } catch {
                            lastEnsureError = error.localizedDescription
                            self.updatePostFlashRecovery(
                                status: "设备已重启，正在恢复 USB 网络",
                                progress: "检测到 USB ECM，正在恢复主机地址 198.19.77.2…",
                                progressValue: 0.7,
                                line: "USB 网络恢复重试中: \(lastEnsureError)"
                            )
                            try? await Task.sleep(for: .seconds(1))
                        }
                    }
                    if !ensureSucceeded {
                        self.updatePostFlashRecovery(
                            status: "恢复失败",
                            progress: "设备已重启，但 USB 网络自动恢复失败",
                            progressValue: nil,
                            line: lastEnsureError.isEmpty ? "USB 网络自动恢复失败" : lastEnsureError,
                            finished: true,
                            succeeded: false
                        )
                        self.appendActivity(
                            level: .warning,
                            title: context.activityTitle,
                            message: "设备已重启，但 USB 网络自动恢复失败",
                            detail: lastEnsureError
                        )
                        return
                    }
                    await self.refreshTransportStatus(silent: true)
                    let serviceDeadline = Date().addingTimeInterval(20)
                    while !Task.isCancelled, Date() < serviceDeadline {
                        try? await Task.sleep(for: .seconds(1))
                        await self.refreshBoardStatus(silent: true)
                        self.ensureBoardMonitoring(forceImmediate: true)
                        let boardReady = self.status?.board?.ping == true &&
                            self.status?.board?.ssh_port_open == true &&
                            self.status?.board?.control_service == true
                        if boardReady {
                            self.updatePostFlashRecovery(
                                status: "设备已恢复在线",
                                progress: "Ping / SSH / 控制服务已恢复",
                                progressValue: 1.0,
                                line: "Ping / SSH / 控制服务已恢复",
                                finished: true,
                                succeeded: true
                            )
                            self.sendUserNotification(title: context.activityTitle, message: "设备已恢复在线")
                            let keepVisibleSeconds: UInt64 = 3_000_000_000
                            try? await Task.sleep(nanoseconds: keepVisibleSeconds)
                            if !Task.isCancelled {
                                self.clearPostFlashRecovery()
                            }
                            return
                        }
                        let pingReady = self.status?.board?.ping == true
                        let sshReady = self.status?.board?.ssh_port_open == true
                        let controlReady = self.status?.board?.control_service == true
                        let waitingParts = [
                            pingReady ? nil : "Ping",
                            sshReady ? nil : "SSH",
                            controlReady ? nil : "控制服务"
                        ].compactMap { $0 }
                        self.updatePostFlashRecovery(
                            status: "设备已重启，服务仍在恢复中",
                            progress: "USB 网络已恢复，等待板卡服务恢复…",
                            progressValue: 0.95,
                            line: waitingParts.isEmpty ? "等待板卡服务恢复" : "等待恢复: \(waitingParts.joined(separator: " / "))"
                        )
                    }
                    self.updatePostFlashRecovery(
                        status: "设备已重启，服务恢复超时",
                        progress: "USB 网络已恢复，但板卡服务未在预期时间内恢复",
                        progressValue: nil,
                        line: "20 秒内未恢复 Ping / SSH / 控制服务",
                        finished: true,
                        succeeded: false
                    )
                    self.appendActivity(
                        level: .warning,
                        title: context.activityTitle,
                        message: "USB 网络已恢复，但板卡服务未在预期时间内恢复"
                    )
                    return
                }
                self.updatePostFlashRecovery(
                    status: context == .flash ? "刷写完成，等待设备重启" : "设备重启中，等待重新连接",
                    progress: "正在等待设备重启并重新枚举为 USB ECM…",
                    progressValue: 0.2,
                    line: context == .flash ? "设备尚未回到 USB ECM" : "设备尚未重新连接到 USB ECM"
                )
                try? await Task.sleep(for: .seconds(1))
            }
            if !Task.isCancelled {
                self.updatePostFlashRecovery(
                    status: "恢复超时",
                    progress: "刷写已完成，但设备尚未在预期时间内恢复",
                    progressValue: nil,
                    line: "45 秒内未检测到设备恢复到 USB ECM",
                    finished: true,
                    succeeded: false
                )
                self.appendActivity(
                    level: .warning,
                    title: context.activityTitle,
                    message: "刷写已完成，但设备尚未在预期时间内恢复到 USB ECM"
                )
            }
        }
    }

    func prettyTaskOutput(_ task: ToolkitTask?) -> String {
        taskTimelineLines(for: task).joined(separator: "\n")
    }

    func taskProgressLine(for task: ToolkitTask?) -> String {
        taskDisplaySummary(for: task).progress
    }

    func taskTimelineLines(for task: ToolkitTask?) -> [String] {
        taskDisplaySummary(for: task).lines
    }

    func taskProgressValue(for task: ToolkitTask?) -> Double? {
        if !pendingTaskTitle.isEmpty && task == nil {
            return 0.05
        }
        guard let task else {
            return nil
        }
        if task.status == "finished" {
            return task.ok == true ? 1.0 : nil
        }
        let output = task.output_tail ?? ""
        let action = task.action ?? ""
        return progressValue(for: action, output: output)
    }

    private func progressValue(for action: String, output: String) -> Double? {
        let text = output.lowercased()
        switch action {
        case "release-install-environment":
            var progress = 0.05
            if text.contains("downloading remote manifest") || text.contains("probing") {
                progress = max(progress, 0.12)
            }
            if text.contains("loading official image") || text.contains("downloading official image archive") || text.contains("official image already available") || text.contains("building official image") {
                progress = max(progress, 0.28)
            }
            if text.contains("importing host images") || text.contains("downloading host images") {
                progress = max(progress, 0.48)
            }
            if text.contains("importing official workspace") || text.contains("downloading full workspace payload") || text.contains("seeding full development volume") {
                progress = max(progress, 0.72)
            }
            if text.contains("optional qt host tools") {
                progress = max(progress, 0.84)
            }
            if text.contains("verifying release environment") {
                progress = max(progress, 0.93)
            }
            if text.contains("full development environment install completed") {
                progress = 1.0
            }
            return progress
        case "release-update-toolkit":
            var progress = 0.08
            if text.contains("downloading update manifest") || text.contains("remote version") {
                progress = max(progress, 0.2)
            }
            if text.contains("downloading toolkit bundle") || text.contains("update bundle is reachable") {
                progress = max(progress, 0.55)
            }
            if text.contains("extracting") || text.contains("installing") || text.contains("verifying") {
                progress = max(progress, 0.85)
            }
            if text.contains("replacing installed application") {
                progress = max(progress, 0.96)
            }
            if text.contains("toolkit update completed") || text.contains("installed app:") {
                progress = 1.0
            }
            return progress
        case "release-update-images":
            var progress = 0.08
            if text.contains("downloading host images") || text.contains("host image bundle is reachable") {
                progress = max(progress, 0.45)
            }
            if text.contains("importing host images") {
                progress = max(progress, 0.82)
            }
            return progress
        default:
            return nil
        }
    }

    private func taskDisplaySummary(for task: ToolkitTask?) -> (progress: String, lines: [String]) {
        guard let task else {
            if !pendingTaskTitle.isEmpty {
                return ("正在初始化日志流…", [])
            }
            return ("等待日志输出…", [])
        }
        if let output = task.output_tail, !output.isEmpty {
            let compact = compactTaskOutput(
                output,
                action: task.action ?? "",
                isFinished: task.status == "finished",
                isSuccess: task.ok == true
            )
            if !compact.progress.isEmpty || !compact.lines.isEmpty {
                return compact
            }
        }
        if let logPath = task.log_path, !logPath.isEmpty {
            return ("正在初始化日志流…", ["日志文件: \(logPath)"])
        }
        return ("等待日志输出…", [])
    }

    func taskStatusText(for task: ToolkitTask?) -> String {
        guard pendingTaskTitle.isEmpty else {
            return ""
        }
        guard let task else {
            return ""
        }
        if task.status == "finished" {
            if task.ok == true {
                if task.action == "flash" {
                    return "下载成功，正在重启设备…"
                }
                return "执行完成"
            }
            return "执行失败"
        }
        return ""
    }

    private func compactTaskOutput(_ output: String, action: String, isFinished: Bool, isSuccess: Bool) -> (progress: String, lines: [String]) {
        let planPattern = #"\[stage\] plan\s+(\S+)\s+file=.* offset=(0x[0-9a-fA-F]+) write_sectors=0x([0-9a-fA-F]+)"#
        let writePattern = #"rkflashtool: info: writing flash memory at offset (0x[0-9a-fA-F]+)(\.\.\. Done!)?"#
        let chunkPattern = #"Using LBA read/write chunk size (\d+) sectors"#
        let lines = output
            .replacingOccurrences(of: "\r", with: "\n")
            .split(separator: "\n", omittingEmptySubsequences: false)
            .map { String($0) }

        var stageLines: [String] = []
        var infoLines: [String] = []
        var partitionName = ""
        var startOffset: Int?
        var totalSectors: Int?
        var currentOffset: Int?
        var chunkSectors: Int = 0
        var writeDone = false

        for rawLine in lines {
            let line = rawLine.trimmingCharacters(in: .whitespacesAndNewlines)
            if line.isEmpty {
                continue
            }

            if let groups = regexGroups(in: line, pattern: chunkPattern), let value = Int(groups[0]) {
                chunkSectors = value
                continue
            }

            if let groups = regexGroups(in: line, pattern: planPattern), groups.count >= 3 {
                partitionName = groups[0]
                startOffset = Int(String(groups[1]).dropFirst(2), radix: 16)
                totalSectors = Int(String(groups[2]), radix: 16)
                stageLines.append(line)
                continue
            }

            if let groups = regexGroups(in: line, pattern: writePattern), !groups.isEmpty {
                currentOffset = Int(String(groups[0]).dropFirst(2), radix: 16)
                writeDone = line.contains("... Done!")
                continue
            }

            if line.contains("USB device scan") ||
                line.contains("descriptor:") ||
                line.contains("interface=") ||
                line.contains("ep=0x") ||
                line.contains("strings:") ||
                line.contains("kernel_driver_") ||
                line.contains("claim_interface_") ||
                line.contains("mode_hint:") ||
                line.contains("config: source=") {
                continue
            }

            if line.hasPrefix("[stage]") {
                stageLines.append(line)
                continue
            }

            if line.hasPrefix("rkflashtool: info:") {
                infoLines.append(line)
                continue
            }

            infoLines.append(line)
        }

        let cleanedStages = dedupeConsecutive(stageLines.map { cleanTaskLine($0) })
        var result: [String] = Array(cleanedStages.suffix(6))
        var progress = ""

        if let currentOffset {
            let displayName = partitionName.isEmpty ? "当前分区" : partitionName
            if let startOffset, let totalSectors, totalSectors > 0 {
                var completed = max(0, currentOffset - startOffset)
                if chunkSectors > 0 {
                    completed += chunkSectors
                }
                if writeDone {
                    completed = totalSectors
                }
                let percent = max(0, min(100, Int((Double(completed) / Double(totalSectors)) * 100.0)))
                progress = "刷写进度: \(displayName) \(percent)%"
            } else {
                progress = "刷写进度: offset \(String(format: "0x%08x", currentOffset))"
            }
        } else if action == "flash" && output.contains("waiting for target board") {
            progress = "正在等待开发板进入 Loader…"
        } else if action == "flash" {
            progress = "正在准备刷写任务…"
        }

        let filteredInfo = infoLines.filter {
            !$0.contains("writing flash memory at offset") &&
            !$0.contains("USB device scan")
        }.map { cleanTaskLine($0) }
        result.append(contentsOf: dedupeConsecutive(filteredInfo).suffix(3))

        if action == "flash" && isFinished && isSuccess {
            progress = "下载成功，正在重启设备…"
        } else if isFinished && isSuccess {
            progress = "执行完成"
        }

        return (progress, Array(result.suffix(6)))
    }

    private func regexGroups(in text: String, pattern: String) -> [String]? {
        guard let regex = try? NSRegularExpression(pattern: pattern) else {
            return nil
        }
        let range = NSRange(text.startIndex..<text.endIndex, in: text)
        guard let match = regex.firstMatch(in: text, range: range), match.numberOfRanges > 1 else {
            return nil
        }
        return (1..<match.numberOfRanges).compactMap { index in
            let groupRange = match.range(at: index)
            guard groupRange.location != NSNotFound, let swiftRange = Range(groupRange, in: text) else {
                return nil
            }
            return String(text[swiftRange])
        }
    }

    private func cleanTaskLine(_ line: String) -> String {
        let cleaned = line
            .replacingOccurrences(of: "[stage] ", with: "")
            .replacingOccurrences(of: "rkflashtool: info: ", with: "")
        if cleaned.hasPrefix("command: ") {
            return cleaned.replacingOccurrences(of: "command: ", with: "执行入口: ")
        }
        if cleaned.hasPrefix("process started: ") {
            return cleaned.replacingOccurrences(of: "process started: ", with: "后台任务已启动: ")
        }
        return cleaned
    }

    private func dedupeConsecutive(_ lines: [String]) -> [String] {
        var result: [String] = []
        for line in lines {
            if result.last != line {
                result.append(line)
            }
        }
        return result
    }

    func makeSnapshot(from status: ToolkitStatus) -> StatusSnapshot {
        StatusSnapshot(
            serviceRunning: serviceRunning,
            usbMode: status.usb?.mode ?? "-",
            usbProduct: status.usb?.product ?? "-",
            usbPid: status.usb?.pid ?? "-",
            usbIface: status.usbnet?.iface ?? "-",
            hostIP: status.usbnet?.current_ip ?? "-",
            usbConfigured: status.usbnet?.configured ?? false,
            ping: status.board?.ping ?? false,
            ssh: status.board?.ssh_port_open ?? false,
            controlService: status.board?.control_service ?? false,
            dockerReady: status.host?.docker_daemon ?? false,
            usbnetHelperInstalled: status.host?.usbnet_helper_installed ?? false
        )
    }

    func recordStatusChanges(from old: StatusSnapshot, to new: StatusSnapshot) {
        var changes: [(ActivityLevel, String, String)] = []

        if old.usbMode != new.usbMode {
            changes.append((.info, "USB 模式变化", "\(old.usbMode) -> \(new.usbMode)"))
        }
        if old.hostIP != new.hostIP || old.usbConfigured != new.usbConfigured {
            let message = "主机地址 \(old.hostIP) -> \(new.hostIP)"
            changes.append((new.usbConfigured ? .success : .warning, "USB 网络变化", message))
        }
        if old.ping != new.ping {
            changes.append((new.ping ? .success : .warning, "板卡连通性变化", new.ping ? "开发板已在线" : "开发板已离线"))
        }
        if old.ssh != new.ssh {
            changes.append((new.ssh ? .success : .warning, "SSH 状态变化", new.ssh ? "SSH 已可连接" : "SSH 不可连接"))
        }
        if old.controlService != new.controlService {
            changes.append((new.controlService ? .success : .warning, "控制服务变化", new.controlService ? "usb0 控制服务已恢复" : "usb0 控制服务不可达"))
        }
        if old.dockerReady != new.dockerReady {
            changes.append((new.dockerReady ? .success : .warning, "Docker 状态变化", new.dockerReady ? "Docker 已就绪" : "Docker 未就绪"))
        }
        if old.usbnetHelperInstalled != new.usbnetHelperInstalled {
            changes.append((
                new.usbnetHelperInstalled ? .success : .warning,
                "网络权限变化",
                new.usbnetHelperInstalled ? "主机 USB 网络权限已安装" : "主机 USB 网络权限未安装"
            ))
        }

        for change in changes {
            appendActivity(level: change.0, title: change.1, message: change.2)
            sendUserNotification(title: change.1, message: change.2)
        }
    }

    func ensureServiceStartedIfNeeded() async {
        if serviceStartInProgress {
            return
        }
        await refreshServiceState()
        if serviceRunning {
            didBootstrapService = true
            return
        }
        serviceStartInProgress = true
        defer { serviceStartInProgress = false }
        do {
            let output = try await runPlainAction(["start", "--port", String(servicePort)])
            serviceRunning = true
            appendActivity(level: .success, title: "本地服务", message: "已自动启动", detail: output)
        } catch {
            appendActivity(level: .warning, title: "本地服务", message: "未能自动启动，将退回直连模式", detail: error.localizedDescription)
        }
        didBootstrapService = true
    }

    func restartServiceForWorkspaceModeSwitch() {
        busy = true
        Task {
            stopEventStream()
            transitionWatchTask?.cancel()
            taskPollTask?.cancel()
            currentTask = nil
            pendingTaskTitle = ""
            serviceRunning = false
            didBootstrapService = false
            lastSnapshot = nil
            status = nil
            do {
                _ = try await runPlainAction(["stop", "--port", String(servicePort)])
            } catch {
                // Ignore stop failures; the new service start path below is authoritative.
            }
            await ensureServiceStartedIfNeeded()
            refreshStatus(silent: true)
            startEventStream()
            busy = false
        }
    }

    func applyStatusUpdate(_ newStatus: ToolkitStatus, silent: Bool = false) {
        lastEventAt = Date()
        let stableStatus = stabilizedStatus(from: newStatus)
        let newSnapshot = makeSnapshot(from: stableStatus)
        let previousSnapshot = lastSnapshot
        if let oldSnapshot = previousSnapshot, oldSnapshot != newSnapshot {
            recordStatusChanges(from: oldSnapshot, to: newSnapshot)
        } else if previousSnapshot == nil, !silent {
            appendActivity(level: .success, title: "状态监控", message: "已建立实时订阅")
        }
        if previousSnapshot == newSnapshot {
            if newSnapshot.usbMode == "usb-ecm" && newSnapshot.usbConfigured &&
                newSnapshot.ping && newSnapshot.ssh {
                boardStateGraceUntil = nil
            }
            persistWorkspaceSelection()
            lastRefreshErrorSignature = ""
            return
        }
        status = stableStatus
        lastSnapshot = newSnapshot
        if newSnapshot.usbMode == "usb-ecm" && newSnapshot.usbConfigured &&
            newSnapshot.ping && newSnapshot.ssh {
            boardStateGraceUntil = nil
        }
        persistWorkspaceSelection()
        lastRefreshErrorSignature = ""
    }

    func stabilizedStatus(from status: ToolkitStatus) -> ToolkitStatus {
        guard let current = self.status else {
            return status
        }

        let withinGrace = boardStateGraceUntil.map { Date() < $0 } ?? false
        let usbLooksStable = (status.usb?.mode == "usb-ecm") && (status.usbnet?.configured == true)
        guard withinGrace, usbLooksStable else {
            return status
        }

        let previousBoard = current.board
        let nextBoard = status.board
        let stabilizedBoard = ToolkitStatus.Board(
            ping: (previousBoard?.ping == true && nextBoard?.ping == false) ? true : nextBoard?.ping,
            ssh_port_open: (previousBoard?.ssh_port_open == true && nextBoard?.ssh_port_open == false) ? true : nextBoard?.ssh_port_open,
            control_service: (previousBoard?.control_service == true && nextBoard?.control_service == false) ? true : nextBoard?.control_service
        )

        return ToolkitStatus(
            repo_root: status.repo_root,
            service: status.service,
            updated_at: status.updated_at,
            usb: status.usb,
            usbnet: status.usbnet,
            board: stabilizedBoard,
            host: status.host
        )
    }

    func startBackgroundMonitoring() {
        guard !monitoringStarted else {
            return
        }
        monitoringStarted = true
        systemMonitor = SystemEventMonitor { [weak self] reason in
            self?.handleSystemEvent(reason)
        }
        systemMonitor?.start()
        startTransportMonitor()
        startHostMonitor()
        startServiceMonitor()
        Task {
            await refreshTransportStatus(silent: true)
            await refreshHostStatus(silent: true)
            await refreshServiceState()
            if status?.usb?.mode == "usb-ecm", status?.usbnet?.configured == true {
                ensureBoardMonitoring(forceImmediate: true)
            }
        }
        startEventStream()
        startWatchdog()
    }

    func handleSystemEvent(_ reason: String) {
        if isFlashTaskRunning {
            return
        }
        if reason == "usb-removed" {
            boardStateGraceUntil = nil
            stopBoardMonitoring()
            applyDisconnectedUSBState()
        } else if reason == "usb-added" {
            boardStateGraceUntil = Date().addingTimeInterval(8)
            applyTransientUSBStateIfNeeded()
        } else if reason == "network", status?.usb?.mode == "usb-ecm" {
            boardStateGraceUntil = Date().addingTimeInterval(5)
        }
        pendingSystemRefreshTask?.cancel()
        pendingSystemRefreshTask = Task { [weak self] in
            let delay = reason.hasPrefix("usb") ? Duration.milliseconds(40) : Duration.milliseconds(120)
            try? await Task.sleep(for: delay)
            guard let self, !Task.isCancelled else {
                return
            }
            await self.refreshTransportStatus(silent: true)
            self.startTransitionWatch(reason: reason)
        }
    }

    func applyTransientUSBStateIfNeeded() {
        guard let current = status else {
            return
        }
        if current.usb?.mode == "usb-ecm", current.usbnet?.configured == true {
            return
        }
        applyTransientUSBState(from: current)
    }

    func applyTransientUSBState(from current: ToolkitStatus) {
        resetBoardFailureCounters()
        let transient = ToolkitStatus(
            repo_root: current.repo_root,
            service: current.service,
            updated_at: current.updated_at,
            usb: .init(
                mode: "detecting",
                product: current.usb?.product,
                pid: current.usb?.pid
            ),
            usbnet: .init(
                iface: current.usbnet?.iface,
                current_ip: nil,
                expected_ip: current.usbnet?.expected_ip,
                configured: false
            ),
            board: .init(
                ping: false,
                ssh_port_open: false,
                control_service: false
            ),
            host: current.host
        )
        status = transient
        lastSnapshot = makeSnapshot(from: transient)
    }

    func applyDisconnectedUSBState() {
        guard let current = status else {
            return
        }
        resetBoardFailureCounters()
        let disconnected = ToolkitStatus(
            repo_root: current.repo_root,
            service: current.service,
            updated_at: current.updated_at,
            usb: .init(
                mode: "absent",
                product: nil,
                pid: nil
            ),
            usbnet: .init(
                iface: nil,
                current_ip: nil,
                expected_ip: current.usbnet?.expected_ip,
                configured: false
            ),
            board: .init(
                ping: false,
                ssh_port_open: false,
                control_service: false
            ),
            host: current.host
        )
        status = disconnected
        lastSnapshot = makeSnapshot(from: disconnected)
    }

    func startTransitionWatch(reason: String, duration: TimeInterval = 28, step: TimeInterval = 1.0) {
        transitionWatchTask?.cancel()
        transitionWatchTask = Task { [weak self] in
            guard let self else {
                return
            }
            let started = Date()
            var stableTicks = 0
            var previous = self.lastSnapshot
            while !Task.isCancelled, Date().timeIntervalSince(started) < duration {
                let currentStep: TimeInterval = Date().timeIntervalSince(started) < 4 ? 0.35 : step
                try? await Task.sleep(for: .seconds(currentStep))
                guard !Task.isCancelled else {
                    return
                }
                await self.refreshTransportStatus(silent: true)
                if self.status?.usb?.mode == "usb-ecm", self.status?.usbnet?.configured == true {
                    await self.refreshBoardStatus(silent: true)
                }
                if self.lastSnapshot == previous {
                    stableTicks += 1
                } else {
                    stableTicks = 0
                    previous = self.lastSnapshot
                }
                if stableTicks >= 3, Date().timeIntervalSince(started) >= 6 {
                    break
                }
            }
            if reason == "usb" || reason == "network" {
                self.appendActivity(level: .info, title: "状态跟踪", message: "已完成 \(reason) 变化后的状态同步")
            }
        }
    }

    func resetBoardFailureCounters() {
        boardPingFalseCount = 0
        boardSSHFalseCount = 0
        boardControlFalseCount = 0
    }

    func stabilizedBoardStatus(_ nextBoard: ToolkitStatus.Board?) -> ToolkitStatus.Board {
        let incoming = nextBoard ?? ToolkitStatus.Board(ping: false, ssh_port_open: false, control_service: false)
        let current = status?.board ?? ToolkitStatus.Board(ping: false, ssh_port_open: false, control_service: false)

        func stableValue(
            incoming: Bool?,
            current: Bool?,
            counter: inout Int
        ) -> Bool {
            let next = incoming ?? false
            let previous = current ?? false

            if next {
                counter = 0
                return true
            }

            if !previous {
                counter = 0
                return false
            }

            counter += 1
            if counter >= boardFalseThreshold {
                counter = 0
                return false
            }
            return true
        }

        return ToolkitStatus.Board(
            ping: stableValue(incoming: incoming.ping, current: current.ping, counter: &boardPingFalseCount),
            ssh_port_open: stableValue(incoming: incoming.ssh_port_open, current: current.ssh_port_open, counter: &boardSSHFalseCount),
            control_service: stableValue(incoming: incoming.control_service, current: current.control_service, counter: &boardControlFalseCount)
        )
    }

    func serviceEventURL() -> URL {
        serviceBaseURL.appendingPathComponent("api/events")
    }

    func startEventStream() {
        eventTask?.cancel()
        eventTask = Task { [weak self] in
            await self?.runEventStreamLoop()
        }
    }

    func stopEventStream() {
        eventTask?.cancel()
        eventTask = nil
    }

    func startWatchdog() {
        watchdogTask?.cancel()
        watchdogTask = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(for: .seconds(4))
                guard let self else {
                    return
                }
                if self.isFlashTaskRunning {
                    continue
                }
                let age = Date().timeIntervalSince(self.lastEventAt)
                if age > 8 {
                    self.stopEventStream()
                    self.startEventStream()
                    self.lastEventAt = Date()
                }
            }
        }
    }

    func recoverFromIncompatibleService() async {
        let now = Date()
        if lastIncompatibleServiceRecoveryAt == nil || now.timeIntervalSince(lastIncompatibleServiceRecoveryAt!) > 20 {
            appendActivity(level: .warning, title: "本地服务版本", message: "检测到旧版服务，正在重启")
            lastIncompatibleServiceRecoveryAt = now
        }
        _ = try? await runPlainAction(["stop", "--port", String(servicePort)])
        didBootstrapService = false
        serviceRunning = false
    }

    func runEventStreamLoop() async {
        while !Task.isCancelled {
            await ensureServiceStartedIfNeeded()
            if !serviceRunning {
                try? await Task.sleep(for: .seconds(2))
                continue
            }

            do {
                var request = URLRequest(url: serviceEventURL())
                request.timeoutInterval = 0
                let (bytes, response) = try await URLSession.shared.bytes(for: request)
                guard let http = response as? HTTPURLResponse else {
                    throw ToolkitGUIError.commandFailed("事件流连接失败")
                }
                if http.statusCode == 404 {
                    if let status = try? await fetchServiceStatus(),
                       (status.service?.api_version ?? 0) >= requiredServiceAPIVersion {
                        serviceRunning = true
                        try? await Task.sleep(for: .seconds(1))
                        continue
                    }
                    await recoverFromIncompatibleService()
                    try? await Task.sleep(for: .seconds(1))
                    continue
                }
                guard http.statusCode == 200 else {
                    throw ToolkitGUIError.commandFailed("事件流连接失败")
                }
                serviceRunning = true
                lastEventAt = Date()

                var eventName = ""
                var dataLines: [String] = []

                for try await line in bytes.lines {
                    if Task.isCancelled {
                        return
                    }
                    lastEventAt = Date()
                    if line.hasPrefix("event:") {
                        eventName = String(line.dropFirst(6)).trimmingCharacters(in: .whitespaces)
                        continue
                    }
                    if line.hasPrefix("data:") {
                        dataLines.append(String(line.dropFirst(5)).trimmingCharacters(in: .whitespaces))
                        continue
                    }
                    if line.isEmpty {
                        guard !dataLines.isEmpty else {
                            continue
                        }
                        let payload = dataLines.joined(separator: "\n")
                        dataLines.removeAll(keepingCapacity: true)
                        let data = Data(payload.utf8)
                        if eventName == "task" {
                            let taskEvent = try JSONDecoder().decode(TaskServiceEvent.self, from: data)
                            if let task = taskEvent.task {
                                handleTaskUpdate(task)
                            }
                            eventName = ""
                            continue
                        }
                        let serviceEvent = try JSONDecoder().decode(ServiceEvent.self, from: data)
                        if eventName == "status" || serviceEvent.event == "status" || serviceEvent.state != nil {
                            serviceRunning = true
                            Task { [weak self] in
                                guard let self else { return }
                                await self.refreshTransportStatus(silent: true)
                                await self.refreshHostStatus(silent: true)
                                if self.status?.usb?.mode == "usb-ecm", self.status?.usbnet?.configured == true {
                                    await self.refreshBoardStatus(silent: true)
                                }
                            }
                        } else if serviceEvent.event == nil {
                            let taskEvent = try? JSONDecoder().decode(TaskServiceEvent.self, from: data)
                            if let task = taskEvent?.task {
                                handleTaskUpdate(task)
                            }
                        }
                        eventName = ""
                    }
                }
                throw ToolkitGUIError.commandFailed("事件流连接已断开")
            } catch is CancellationError {
                return
            } catch {
                if (try? await fetchServiceStatus()) != nil {
                    serviceRunning = true
                } else {
                    serviceRunning = false
                }
                let signature = "事件流已断开：\(error.localizedDescription)"
                if signature != lastRefreshErrorSignature {
                    appendActivity(level: .warning, title: "状态订阅", message: "连接中断，正在重连", detail: error.localizedDescription)
                    lastRefreshErrorSignature = signature
                }
                try? await Task.sleep(for: .seconds(2))
            }
        }
    }

    func refreshStatus(silent: Bool = false) {
        if isFlashTaskRunning {
            return
        }
        if busy && !silent {
            return
        }
        refreshSequence += 1
        let sequence = refreshSequence
        if !silent {
            busy = true
        }
        Task {
            do {
                _ = try workspaceURL()
                await ensureServiceStartedIfNeeded()
                await refreshServiceState()
                guard sequence == self.refreshSequence else {
                    if !silent {
                        self.busy = false
                    }
                    return
                }
                await refreshTransportStatus(silent: true)
                await refreshHostStatus(silent: true)
                if status?.usb?.mode == "usb-ecm", status?.usbnet?.configured == true {
                    await refreshBoardStatus(silent: true)
                }
            } catch {
                let signature = error.localizedDescription
                if sequence == self.refreshSequence, signature != lastRefreshErrorSignature {
                    presentInlineError("刷新状态失败: \(signature)")
                    appendActivity(level: .error, title: "状态刷新失败", message: signature)
                    lastRefreshErrorSignature = signature
                }
            }
            busy = false
        }
    }

    func runManagedAction(
        title: String,
        successMessage: String,
        serviceArgs: [String],
        localArgs: [String],
        plainText: Bool = false,
        transitionTracking: Bool = false,
        asyncTask: Bool = false,
        recoveryContext: DeviceRecoveryContext? = nil
    ) {
        busy = true
        Task {
            do {
                _ = try workspaceURL()
                await ensureServiceStartedIfNeeded()
                clearInlineError()
                if asyncTask {
                    taskPollTask?.cancel()
                    dismissedFinishedTaskIDs.removeAll()
                    currentTask = nil
                    pendingTaskTitle = title
                }
                if asyncTask, !serviceRunning {
                    throw ToolkitGUIError.commandFailed("异步任务需要本地服务在线")
                }
                let args = serviceRunning ? self.serviceArgs(serviceArgs) : localArgs
                let detail: String
                if asyncTask {
                    let response: TaskResponse
                    if serviceRunning {
                        let payload = self.payloadForServiceAction(serviceArgs)
                        let serviceResponse = try await postServiceAction(
                            action: payload.action,
                            payload: payload.payload,
                            async: true
                        )
                        response = TaskResponse(ok: serviceResponse.ok, action: serviceResponse.action, task: serviceResponse.task, error: serviceResponse.error)
                    } else {
                        response = try await runTaskAction(args)
                    }
                    pendingTaskTitle = ""
                    currentTask = response.task
                    busy = false
                    if let taskID = response.task?.id {
                        appendActivity(level: .info, title: title, message: "任务已启动", detail: response.task?.log_path)
                        pollTask(taskID)
                    }
                    detail = response.task?.log_path ?? ""
                } else if plainText {
                    detail = try await runPlainAction(args)
                } else {
                    if serviceRunning {
                        let payload = self.payloadForServiceAction(serviceArgs)
                        let response = try await postServiceAction(
                            action: payload.action,
                            payload: payload.payload,
                            async: false
                        )
                        detail = response.output ?? ""
                    } else {
                        let response = try await runJSONAction(args)
                        detail = response.output ?? response.output_tail ?? response.log_path ?? ""
                    }
                }
                appendActivity(level: .success, title: title, message: successMessage, detail: detail)
                if let recoveryContext, !asyncTask {
                    startPostFlashRecovery(recoveryContext)
                }
                if transitionTracking {
                    startTransitionWatch(reason: title, duration: 14, step: 1.0)
                }
                if !asyncTask {
                    refreshStatus(silent: true)
                }
            } catch {
                let detail = error.localizedDescription
                pendingTaskTitle = ""
                presentInlineError(detail)
                appendActivity(level: .error, title: title, message: "执行失败", detail: detail)
                busy = false
            }
            if !asyncTask {
                busy = false
            }
        }
    }

    func payloadForServiceAction(_ arguments: [String]) -> (action: String, payload: [String: Any]) {
        guard let first = arguments.first else {
            return ("status", [:])
        }
        switch first {
        case "check-host":
            return ("check-host", ["mode": arguments.dropFirst().first(where: { !$0.hasPrefix("--") }) ?? "all"])
        case "usbnet":
            let sub = arguments.dropFirst().first(where: { !$0.hasPrefix("--") }) ?? "status"
            return ("usbnet-\(sub)", [:])
        case "usb":
            let sub = arguments.dropFirst().first(where: { !$0.hasPrefix("--") }) ?? "detect"
            switch sub {
            case "reboot-loader":
                return ("usb-reboot-loader", [:])
            case "reboot-device":
                return ("usb-reboot-device", [:])
            case "authorize-key":
                return ("usb-authorize-key", [:])
            default:
                return ("detect-usb", [:])
            }
        case "flash":
            let partition = arguments.dropFirst().first(where: { !$0.hasPrefix("--") }) ?? "all"
            return ("flash", ["partition": partition])
        case "dev":
            let sub = arguments.dropFirst().first(where: { !$0.hasPrefix("--") }) ?? ""
            return ("dev-\(sub)", [:])
        case "release":
            let sub = arguments.dropFirst().first(where: { !$0.hasPrefix("--") }) ?? ""
            var payload: [String: Any] = [:]
            if let artifactsIndex = arguments.firstIndex(of: "--artifacts-dir"), arguments.indices.contains(arguments.index(after: artifactsIndex)) {
                payload["artifacts_dir"] = arguments[arguments.index(after: artifactsIndex)]
            }
            if let logoIndex = arguments.firstIndex(of: "--logo"), arguments.indices.contains(arguments.index(after: logoIndex)) {
                payload["logo_path"] = arguments[arguments.index(after: logoIndex)]
            }
            if let dtsIndex = arguments.firstIndex(of: "--dts-file"), arguments.indices.contains(arguments.index(after: dtsIndex)) {
                payload["dts_file"] = arguments[arguments.index(after: dtsIndex)]
            }
            if let rotateIndex = arguments.firstIndex(of: "--rotate"), arguments.indices.contains(arguments.index(after: rotateIndex)) {
                payload["rotate"] = arguments[arguments.index(after: rotateIndex)]
            }
            if let scaleIndex = arguments.firstIndex(of: "--scale"), arguments.indices.contains(arguments.index(after: scaleIndex)) {
                payload["scale"] = arguments[arguments.index(after: scaleIndex)]
            }
            if arguments.contains("--flash") {
                payload["flash"] = true
            }
            return ("release-\(sub)", payload)
        default:
            return (first, [:])
        }
    }

    func startService() {
        busy = true
        Task {
            do {
                _ = try workspaceURL()
                let output = try await runPlainAction(["start", "--port", String(servicePort)])
                serviceRunning = true
                appendActivity(level: .success, title: "本地服务", message: "已启动", detail: output)
                startEventStream()
                refreshStatus(silent: true)
            } catch {
                let detail = error.localizedDescription
                presentInlineError(detail)
                appendActivity(level: .error, title: "本地服务", message: "启动失败", detail: detail)
            }
            busy = false
        }
    }

    func stopService() {
        busy = true
        Task {
            do {
                let output = try await runPlainAction(["stop", "--port", String(servicePort)])
                stopEventStream()
                serviceRunning = false
                appendActivity(level: .success, title: "本地服务", message: "已停止", detail: output)
            } catch {
                let detail = error.localizedDescription
                presentInlineError(detail)
                appendActivity(level: .error, title: "本地服务", message: "停止失败", detail: detail)
            }
            busy = false
        }
    }

    func checkHost() {
        Task {
            if let message = await validatePrecondition(.checkHost) {
                presentInlineError(message)
                appendActivity(level: .warning, title: "主机预检", message: message)
                return
            }
            runManagedAction(title: "主机预检", successMessage: "检查完成", serviceArgs: ["check-host", "all", "--service"], localArgs: ["check-host", "all"])
        }
    }

    func ensureUSBNet() {
        Task {
            if let message = await validatePrecondition(.ensureUSBNet) {
                presentInlineError(message)
                appendActivity(level: .warning, title: "USB 网络", message: message)
                return
            }
            runManagedAction(title: "USB 网络", successMessage: "主机地址已恢复", serviceArgs: ["usbnet", "ensure", "--service"], localArgs: ["usbnet", "ensure"])
        }
    }

    func installUSBNetHelper() {
        Task {
            if let message = await validatePrecondition(.ensureUSBNet) {
                presentInlineError(message)
                appendActivity(level: .warning, title: "网络权限安装", message: message)
                return
            }
            runManagedAction(
                title: "网络权限安装",
                successMessage: "已安装网络权限并完成地址修复",
                serviceArgs: ["usbnet", "ensure", "--service"],
                localArgs: ["usbnet", "ensure"],
                transitionTracking: true
            )
        }
    }

    func checkDevelopmentEnvironment() {
        Task {
            do {
                let response = try await runJSONAction(["release", "check-env"])
                installerLastDetail = response.output ?? "检查完成"
                appendActivity(level: .success, title: "发布环境检查", message: "检查完成", detail: response.output)
                await refreshDevelopmentInstallStatus()
            } catch {
                let detail = error.localizedDescription
                installerLastDetail = detail
                presentInlineError(detail)
                appendActivity(level: .error, title: "发布环境检查", message: "检查失败", detail: detail)
            }
        }
    }

    func installFullDevelopmentEnvironment() {
        installerLastDetail = "准备开始全量安装..."
        runManagedAction(
            title: "发布环境全量安装",
            successMessage: "全量安装任务已提交",
            serviceArgs: ["release", "install-environment", "--service", "--async"],
            localArgs: ["release", "install-environment"],
            asyncTask: true
        )
    }

    func installFullDevelopmentEnvironmentFromLocal() {
        let trimmed = localArtifactsDir.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            presentInlineError("请先选择本地安装包目录。")
            appendActivity(level: .warning, title: "本地安装", message: "未选择本地安装包目录")
            return
        }
        var isDirectory: ObjCBool = false
        guard FileManager.default.fileExists(atPath: trimmed, isDirectory: &isDirectory), isDirectory.boolValue else {
            presentInlineError("本地安装包目录不存在：\(trimmed)")
            appendActivity(level: .warning, title: "本地安装", message: "本地安装包目录不存在")
            return
        }
        guard localArtifactValidation.ready else {
            presentInlineError("本地安装资源未通过完整性校验，请先完成检查。")
            appendActivity(level: .warning, title: "本地安装", message: "资源校验未通过")
            return
        }
        installerLastDetail = "准备从本地目录导入发布环境..."
        runManagedAction(
            title: "发布环境本地安装",
            successMessage: "本地安装任务已提交",
            serviceArgs: ["release", "install-environment", "--artifacts-dir", trimmed, "--service", "--async"],
            localArgs: ["release", "install-environment", "--artifacts-dir", trimmed],
            asyncTask: true
        )
    }

    func installCodexPlugin() {
        runManagedAction(
            title: "安装 Codex 插件",
            successMessage: "Codex 插件安装任务已提交",
            serviceArgs: ["release", "install-codex-plugin", "--service"],
            localArgs: ["release", "install-codex-plugin"],
            asyncTask: true
        )
        Task {
            try? await Task.sleep(for: .seconds(2))
            await refreshDevelopmentInstallStatus()
        }
    }

    func installOpenCodePlugin() {
        if !developmentInstallStatus.npmReady {
            presentInlineError("未检测到 npm，无法安装 OpenCode 插件。请先安装 Node.js/npm。")
            appendActivity(level: .warning, title: "安装 OpenCode 插件", message: "未检测到 npm")
            return
        }
        runManagedAction(
            title: "安装 OpenCode 插件",
            successMessage: "OpenCode 插件安装任务已提交",
            serviceArgs: ["release", "install-opencode-plugin", "--service"],
            localArgs: ["release", "install-opencode-plugin"],
            asyncTask: true
        )
        Task {
            try? await Task.sleep(for: .seconds(2))
            await refreshDevelopmentInstallStatus()
        }
    }

    func checkToolkitUpdate() {
        updaterLastDetail = "正在检查远程版本..."
        automaticToolkitUpdateInProgress = true
        refreshToolkitUpdateStatus()
        Task {
            do {
                _ = try workspaceURL()
                await ensureServiceStartedIfNeeded()
                let detail = try await runWithTimeout(
                    seconds: 15,
                    failureMessage: "检查更新超时（15 秒），请检查网络连接或服务器状态。"
                ) {
                    if self.serviceRunning {
                        let payload = self.payloadForServiceAction(["release", "check-update", "--service"])
                        let response = try await self.postServiceAction(action: payload.action, payload: payload.payload, async: false)
                        return response.output ?? "检查完成"
                    } else {
                        let response = try await self.runJSONAction(["release", "check-update"])
                        return response.output ?? "检查完成"
                    }
                }
                updaterLastDetail = detail
                parseUpdateStatus(detail: detail)
                appendActivity(level: .success, title: "软件更新", message: toolkitUpdateHeadline, detail: detail)
            } catch {
                let detail = error.localizedDescription
                updaterLastDetail = detail
                presentInlineError(detail)
                appendActivity(level: .error, title: "软件更新", message: "检查失败", detail: detail)
            }
            automaticToolkitUpdateInProgress = false
        }
    }

    func startAutomaticToolkitUpdateFlow() {
        refreshToolkitUpdateStatus()
        guard updateConfigured else {
            updaterLastDetail = "未配置软件更新地址"
            return
        }
        guard !(isUpdaterTask(currentTask) && currentTask?.status != "finished") else {
            return
        }
        automaticToolkitUpdateTask?.cancel()
        automaticToolkitUpdateTask = Task { [weak self] in
            guard let self else {
                return
            }
            defer {
                self.automaticToolkitUpdateTask = nil
                if !(self.isUpdaterTask(self.currentTask) && self.currentTask?.status != "finished") {
                    self.automaticToolkitUpdateInProgress = false
                }
            }
            self.automaticToolkitUpdateInProgress = true
            self.updaterLastDetail = "正在联网检查更新..."
            self.refreshToolkitUpdateStatus()
            do {
                _ = try self.workspaceURL()
                await self.ensureServiceStartedIfNeeded()
                let detail = try await self.runWithTimeout(
                    seconds: 15,
                    failureMessage: "检查更新超时（15 秒），请检查网络连接或服务器状态。"
                ) {
                    if self.serviceRunning {
                        let payload = self.payloadForServiceAction(["release", "check-update", "--service"])
                        let response = try await self.postServiceAction(action: payload.action, payload: payload.payload, async: false)
                        return response.output ?? "检查完成"
                    } else {
                        let response = try await self.runJSONAction(["release", "check-update"])
                        return response.output ?? "检查完成"
                    }
                }
                self.updaterLastDetail = detail
                self.parseUpdateStatus(detail: detail)
                if self.toolkitUpdateStatus.updateAvailable {
                    self.updaterLastDetail = "发现新版本，正在下载安装..."
                    self.shouldRelaunchAfterToolkitUpdate = true
                    self.installToolkitUpdate()
                } else {
                    self.shouldRelaunchAfterToolkitUpdate = false
                    self.updaterLastDetail = "当前已是最新版本"
                    self.appendActivity(level: .success, title: "软件更新", message: "当前已是最新版本")
                }
            } catch {
                self.shouldRelaunchAfterToolkitUpdate = false
                let detail = error.localizedDescription
                self.updaterLastDetail = detail
                self.presentInlineError(detail)
                self.appendActivity(level: .error, title: "软件更新", message: "检查失败", detail: detail)
            }
        }
    }

    func installToolkitUpdate() {
        updaterLastDetail = "准备下载并安装更新..."
        runManagedAction(
            title: "软件更新",
            successMessage: "更新任务已提交",
            serviceArgs: ["release", "update-toolkit", "--service", "--async"],
            localArgs: ["release", "update-toolkit"],
            asyncTask: true
        )
    }

    func updateInitialImages() {
        updaterLastDetail = "准备下载并更新初始镜像..."
        runManagedAction(
            title: "初始镜像更新",
            successMessage: "初始镜像更新任务已提交",
            serviceArgs: ["release", "update-images", "--service", "--async"],
            localArgs: ["release", "update-images"],
            asyncTask: true
        )
    }

    private func relaunchToolkitApplication() {
        let bundleURL = Bundle.main.bundleURL.standardizedFileURL
        guard bundleURL.pathExtension == "app" else {
            return
        }
        let targetPath = bundleURL.path
        let currentPID = ProcessInfo.processInfo.processIdentifier
        Task { @MainActor in
            let helper = Process()
            helper.executableURL = URL(fileURLWithPath: "/bin/bash")
            helper.arguments = [
                "-lc",
                """
                app_path="$1"
                exiting_pid="$2"
                checks=0
                while kill -0 "${exiting_pid}" 2>/dev/null; do
                    checks=$((checks + 1))
                    if [ "${checks}" -ge 50 ]; then
                        break
                    fi
                    sleep 0.2
                done
                sleep 0.5
                exec /usr/bin/open -n "${app_path}"
                """,
                "rk356x-toolkit-relaunch",
                targetPath,
                String(currentPID),
            ]
            helper.standardInput = nil
            helper.standardOutput = FileHandle.nullDevice
            helper.standardError = FileHandle.nullDevice
            try? helper.run()
            try? await Task.sleep(for: .milliseconds(250))
            NSApp.terminate(nil)
        }
    }

    func installOfficialImage() {
        installerLastDetail = "准备构建官方镜像..."
        runManagedAction(
            title: "官方镜像安装",
            successMessage: "官方镜像构建任务已提交",
            serviceArgs: ["release", "build-image", "--service", "--async"],
            localArgs: ["release", "build-image"],
            asyncTask: true
        )
    }

    func installReleaseVolume(profile: String) {
        let title = profile == "bsp-flex" ? "完整开发 Volume" : "基础 Volume"
        installerLastDetail = "准备初始化\(title)..."
        runManagedAction(
            title: title,
            successMessage: "\(title)初始化任务已提交",
            serviceArgs: ["release", "seed-volume", "--profile", profile, "--service", "--async"],
            localArgs: ["release", "seed-volume", "--profile", profile],
            asyncTask: true
        )
    }

    func authorizeKey() {
        Task {
            if let message = await validatePrecondition(.authorizeKey) {
                presentInlineError(message)
                appendActivity(level: .warning, title: "SSH 授权", message: message)
                return
            }
            runManagedAction(title: "SSH 授权", successMessage: "公钥下发完成", serviceArgs: ["usb", "authorize-key", "--service"], localArgs: ["usb", "authorize-key"])
        }
    }

    func rebootLoader() {
        Task {
            if let message = await validatePrecondition(.rebootLoader) {
                presentInlineError(message)
                appendActivity(level: .warning, title: "切换 Loader", message: message)
                return
            }
            runManagedAction(
                title: "切换 Loader",
                successMessage: "已请求开发板切到 Loader",
                serviceArgs: ["usb", "reboot-loader", "--service"],
                localArgs: ["usb", "reboot-loader"],
                transitionTracking: true
            )
        }
    }

    func rebootDevice() {
        Task {
            if let message = await validatePrecondition(.rebootDevice) {
                presentInlineError(message)
                appendActivity(level: .warning, title: "设备重启", message: message)
                return
            }
            runManagedAction(
                title: "设备重启",
                successMessage: "已请求开发板重启",
                serviceArgs: ["usb", "reboot-device", "--service"],
                localArgs: ["usb", "reboot-device"],
                transitionTracking: true,
                recoveryContext: .reboot
            )
        }
    }

    func flash(_ target: String) {
        Task {
            if let message = await validatePrecondition(.flash(target)) {
                presentInlineError(message)
                appendActivity(level: .warning, title: "刷写 \(target)", message: message)
                return
            }
            runManagedAction(
                title: "刷写 \(target)",
                successMessage: "任务已提交",
                serviceArgs: ["flash", target, "--service", "--async"],
                localArgs: ["flash", target, "--async"],
                transitionTracking: true,
                asyncTask: true
            )
        }
    }

    func buildSync() {
        Task {
            if let message = await validatePrecondition(.buildSync) {
                presentInlineError(message)
                appendActivity(level: .warning, title: "开发版构建", message: message)
                return
            }
            runManagedAction(title: "开发版构建", successMessage: "build_and_sync 已执行", serviceArgs: ["dev", "build-sync", "--service"], localArgs: ["dev", "build-sync"])
        }
    }

    func buildSyncFlash() {
        Task {
            if let message = await validatePrecondition(.buildSyncFlash) {
                presentInlineError(message)
                appendActivity(level: .warning, title: "开发版构建并刷写", message: message)
                return
            }
            runManagedAction(title: "开发版构建并刷写", successMessage: "build_sync_and_flash 已执行", serviceArgs: ["dev", "build-sync-flash", "--service"], localArgs: ["dev", "build-sync-flash"])
        }
    }

    func updateLogo() {
        dismissEditingFocus()
        var serviceArgs = ["release", "update-logo", "--logo", logoPath, "--rotate", logoRotate, "--scale", logoScale, "--service", "--async"]
        var localArgs = ["release", "update-logo", "--logo", logoPath, "--rotate", logoRotate, "--scale", logoScale]
        if logoFlashAfter {
            serviceArgs.append("--flash")
            localArgs.append("--flash")
        }
        Task {
            if let message = await validatePrecondition(.updateLogo(flashAfter: logoFlashAfter)) {
                presentInlineError(message)
                appendActivity(level: .warning, title: "启动 Logo", message: message)
                return
            }
            runManagedAction(
                title: "启动 Logo",
                successMessage: "更新任务已提交",
                serviceArgs: serviceArgs,
                localArgs: localArgs,
                asyncTask: true
            )
        }
    }

    func dismissEditingFocus() {
        NSApp.keyWindow?.makeFirstResponder(nil)
    }

    func updateDTB() {
        dismissEditingFocus()
        var serviceArgs = ["release", "update-dtb", "--dts-file", dtsFilePath, "--service", "--async"]
        var localArgs = ["release", "update-dtb", "--dts-file", dtsFilePath]
        if dtsFlashAfter {
            serviceArgs.append("--flash")
            localArgs.append("--flash")
        }
        Task {
            if let message = await validatePrecondition(.updateDTB(flashAfter: dtsFlashAfter)) {
                presentInlineError(message)
                appendActivity(level: .warning, title: "设备树", message: message)
                return
            }
            runManagedAction(
                title: "设备树",
                successMessage: "更新任务已提交",
                serviceArgs: serviceArgs,
                localArgs: localArgs,
                asyncTask: true
            )
        }
    }

    func reconnectMonitoring() {
        stopEventStream()
        lastEventAt = Date()
        refreshStatus(silent: true)
        startEventStream()
    }

    func browseFile(assign: @escaping (String) -> Void) {
        let panel = NSOpenPanel()
        panel.canChooseFiles = true
        panel.canChooseDirectories = false
        if let window = NSApp.keyWindow {
            fileDialogActive = true
            panel.beginSheetModal(for: window) { response in
                self.fileDialogActive = false
                if response == .OK, let url = panel.url {
                    assign(url.path)
                }
            }
            return
        }
        if panel.runModal() == .OK, let url = panel.url {
            assign(url.path)
        }
    }

    func browseDirectory(assign: @escaping (String) -> Void) {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.canCreateDirectories = false
        if let window = NSApp.keyWindow {
            fileDialogActive = true
            panel.beginSheetModal(for: window) { response in
                self.fileDialogActive = false
                if response == .OK, let url = panel.url {
                    assign(url.path)
                }
            }
            return
        }
        if panel.runModal() == .OK, let url = panel.url {
            assign(url.path)
        }
    }

    func validateLocalArtifactsDirectory(showFailureDetails: Bool = false) {
        let trimmed = localArtifactsDir.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            localArtifactValidation = LocalArtifactValidationState()
            return
        }
        var isDirectory: ObjCBool = false
        guard FileManager.default.fileExists(atPath: trimmed, isDirectory: &isDirectory), isDirectory.boolValue else {
            localArtifactValidation = LocalArtifactValidationState(
                checking: false,
                checked: true,
                ready: false,
                summary: "本地安装目录不存在",
                items: [
                    LocalArtifactValidationItem(
                        title: "安装目录",
                        detail: trimmed,
                        ok: false,
                        optional: false
                    )
                ],
                failureDetail: "安装目录不存在：\(trimmed)"
            )
            return
        }

        localArtifactValidation = LocalArtifactValidationState(
            checking: true,
            checked: false,
            ready: false,
            summary: "正在校验本地安装资源...",
            items: []
        )

        Task {
            let state = await validateLocalArtifactsDirectory(at: trimmed)
            localArtifactValidation = state
            _ = showFailureDetails
        }
    }

    private func validateLocalArtifactsDirectory(at path: String) async -> LocalArtifactValidationState {
        struct ArtifactManifest: Decodable {
            let official_image: String?
            let host_images: String?
            let official_workspace: String?
            let qt_host_tools: String?
            let official_image_size_bytes: Int64?
            let host_images_size_bytes: Int64?
            let official_workspace_size_bytes: Int64?
            let qt_host_tools_size_bytes: Int64?
        }

        let directoryURL = URL(fileURLWithPath: path)
        let manifestURL = directoryURL.appendingPathComponent("manifest.json")
        let fileManager = FileManager.default
        let directoryEntries = (try? fileManager.contentsOfDirectory(atPath: path).sorted()) ?? []
        var items: [LocalArtifactValidationItem] = []
        var manifest: ArtifactManifest?

        if fileManager.fileExists(atPath: manifestURL.path) {
            do {
                let data = try Data(contentsOf: manifestURL)
                manifest = try JSONDecoder().decode(ArtifactManifest.self, from: data)
                items.append(.init(
                    title: "manifest.json",
                    detail: manifestURL.path,
                    ok: true,
                    optional: false
                ))
            } catch {
                items.append(.init(
                    title: "manifest.json",
                    detail: "解析失败：\(error.localizedDescription)",
                    ok: false,
                    optional: false
                ))
            }
        } else {
            items.append(.init(
                title: "manifest.json",
                detail: "未找到，将按文件名规则快速匹配资源包",
                ok: true,
                optional: true
            ))
        }

        let checks: [(title: String, required: Bool, names: [String], expectedSize: Int64?)] = {
            var list: [(String, Bool, [String], Int64?)] = []
            let imageCandidates = manifest?.official_image.map { [$0] } ?? []
            let hostImageCandidates = manifest?.host_images.map { [$0] } ?? []
            let workspaceCandidates = manifest?.official_workspace.map { [$0] } ?? []
            let qtCandidates = manifest?.qt_host_tools.map { [$0] } ?? []
            list.append(("共享镜像包", true, imageCandidates.isEmpty ? ["tspi-rk356x-env-*.tar.gz"] : imageCandidates, manifest?.official_image_size_bytes))
            list.append(("恢复镜像包", true, hostImageCandidates.isEmpty ? ["tspi-img-*.tar.gz"] : hostImageCandidates, manifest?.host_images_size_bytes))
            list.append(("发布工作区包", true, workspaceCandidates.isEmpty ? ["official-workspace-*.tar.gz"] : workspaceCandidates, manifest?.official_workspace_size_bytes))
            list.append(("Qt 编译环境包", false, qtCandidates.isEmpty ? ["qt6Host-*.tar.gz", "qt6host-*.tar.gz"] : qtCandidates, manifest?.qt_host_tools_size_bytes))
            return list
        }()

        func matches(_ filename: String, pattern: String) -> Bool {
            let predicate = NSPredicate(format: "SELF LIKE[c] %@", pattern)
            return predicate.evaluate(with: filename)
        }

        func firstMatch(patterns: [String]) -> String? {
            for pattern in patterns {
                if !pattern.contains("*") {
                    let expanded = directoryURL.appendingPathComponent(pattern)
                    if fileManager.fileExists(atPath: expanded.path) {
                        return expanded.path
                    }
                }
                if let matched = directoryEntries.first(where: { matches($0, pattern: pattern) }) {
                    return directoryURL.appendingPathComponent(matched).path
                }
            }
            return nil
        }

        func validatePackage(_ filePath: String, expectedSize: Int64?) -> (Bool, String) {
            guard let attrs = try? fileManager.attributesOfItem(atPath: filePath),
                  let actualSize = attrs[.size] as? NSNumber else {
                return (false, "无法读取文件")
            }
            if let expectedSize, expectedSize > 0, actualSize.int64Value != expectedSize {
                return (false, "大小不匹配，期望 \(expectedSize) 字节，实际 \(actualSize.int64Value) 字节")
            }
            return (true, filePath)
        }

        for check in checks {
            if let matched = firstMatch(patterns: check.names) {
                let validation = validatePackage(matched, expectedSize: check.expectedSize)
                items.append(.init(
                    title: check.title,
                    detail: validation.0 ? matched : "\(matched) (\(validation.1))",
                    ok: validation.0,
                    optional: !check.required
                ))
            } else {
                items.append(.init(
                    title: check.title,
                    detail: check.required ? "未找到匹配资源包" : "未提供，可跳过安装",
                    ok: !check.required,
                    optional: !check.required
                ))
            }
        }

        let requiredItems = items.filter { !$0.optional }
        let ready = requiredItems.allSatisfy(\.ok)
        let failureLines = items
            .filter { !$0.ok }
            .map { "• \($0.title)\n  \($0.detail)" }
            .joined(separator: "\n\n")
        return LocalArtifactValidationState(
            checking: false,
            checked: true,
            ready: ready,
            summary: ready ? "本地资源校验通过" : "本地资源校验未通过",
            items: items,
            failureDetail: failureLines
        )
    }

    var workspaceName: String {
        workspaceMode.displayName
    }

    var hasDevelopmentWorkspace: Bool {
        if let developmentRepoRoot {
            return Self.isValidRepoRoot(developmentRepoRoot)
        }
        return false
    }

    var fullDevelopmentEnvironmentReady: Bool {
        developmentInstallStatus.dockerReady &&
        developmentInstallStatus.officialImageReady &&
        developmentInstallStatus.releaseVolumeReady &&
        developmentInstallStatus.hostImagesReady &&
        developmentInstallStatus.rkflashtoolReady
    }

    var developmentInstallHeadline: String {
        if fullDevelopmentEnvironmentReady {
            return "发布环境已完整安装"
        }
        if developmentInstallStatus.dockerReady || developmentInstallStatus.officialImageReady || developmentInstallStatus.releaseVolumeReady || developmentInstallStatus.hostImagesReady {
            return "发布环境部分已安装"
        }
        return "发布环境尚未安装"
    }

    var updateConfigured: Bool {
        toolkitUpdateStatus.configured
    }

    var toolkitVersionText: String {
        toolkitUpdateStatus.currentVersion
    }

    var toolkitUpdateHeadline: String {
        if !toolkitUpdateStatus.configured {
            return "未配置远程更新地址"
        }
        if toolkitUpdateStatus.updateAvailable {
            return "发现新版本"
        }
        if !toolkitUpdateStatus.remoteVersion.isEmpty {
            return "当前已是最新版本"
        }
        return "等待检查更新"
    }

    func isInstallerTask(_ task: ToolkitTask?) -> Bool {
        guard let action = task?.action else {
            return false
        }
        return action == "release-build-image" ||
            action == "release-install-environment" ||
            action == "release-install-codex-plugin" ||
            action == "release-install-opencode-plugin" ||
            action == "release-seed-volume"
    }

    func isUpdaterTask(_ task: ToolkitTask?) -> Bool {
        guard let action = task?.action else {
            return false
        }
        return action == "release-update-toolkit" || action == "release-update-images"
    }

    func switchWorkspaceMode(_ mode: WorkspaceMode) {
        guard mode != workspaceMode else {
            return
        }
        guard mode != .development || hasDevelopmentWorkspace else {
            presentInlineError("当前未检测到开发版安装目录，无法切换到开发版。")
            return
        }
        workspaceMode = mode
        persistWorkspaceSelection()
        restartServiceForWorkspaceModeSwitch()
    }

    var statusHeadline: String {
        let usbMode = status?.usb?.mode ?? "unknown"
        let ping = status?.board?.ping == true ? "在线" : "离线"
        let control = status?.board?.control_service == true ? "控制服务正常" : "控制服务不可达"
        return "\(usbMode) / \(ping) / \(control)"
    }

    var lastUpdatedText: String {
        status?.updated_at ?? "未刷新"
    }

    var shouldShowUSBNetHelperBanner: Bool {
        guard status?.usb?.mode == "usb-ecm" else {
            return false
        }
        guard status?.host?.usbnet_helper_installed == false else {
            return false
        }
        return status?.usbnet?.configured != true
    }

    var taskOverlayVisible: Bool {
        !pendingTaskTitle.isEmpty || currentTask != nil || postFlashRecoveryActive
    }

    var taskOverlayBlocking: Bool {
        if postFlashRecoveryActive {
            return !postFlashRecoveryFinished
        }
        if !pendingTaskTitle.isEmpty {
            return true
        }
        guard let task = currentTask else {
            return false
        }
        return task.status != "finished"
    }

    var menuBarStatusColor: Color {
        if !serviceRunning {
            return .orange
        }
        switch status?.usb?.mode ?? "absent" {
        case "loader":
            return .blue
        case "usb-ecm":
            return status?.board?.ping == true ? .green : .orange
        case "absent":
            return .secondary
        default:
            return .orange
        }
    }
}

struct StatusCard: View {
    let title: String
    let value: String
    let ok: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Circle()
                    .fill(ok ? Color.green : Color.orange)
                    .frame(width: 7, height: 7)
                Text(title)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Text(value)
                .font(.caption.weight(.semibold))
                .lineLimit(1)
                .minimumScaleFactor(0.75)
                .truncationMode(.tail)
                .textSelection(.enabled)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 8)
        .padding(.vertical, 7)
        .background(Color(nsColor: .controlBackgroundColor))
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }
}

struct ActionTile: View {
    let title: String
    let subtitle: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 8) {
                Text(title)
                    .font(.subheadline.weight(.semibold))
                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.leading)
            }
            .frame(maxWidth: .infinity, minHeight: 62, alignment: .topLeading)
            .padding(10)
            .background(Color(nsColor: .controlBackgroundColor))
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
        .buttonStyle(.plain)
    }
}

struct ActivityRow: View {
    let entry: ActivityEntry
    let onDetail: () -> Void

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: entry.level.symbol)
                .foregroundStyle(entry.level.color)
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(entry.title)
                        .font(.headline)
                    Spacer()
                    Text(entry.timestamp.formatted(date: .omitted, time: .standard))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Text(entry.message)
                    .font(.subheadline)
                if entry.detail != nil {
                    Button("查看详情", action: onDetail)
                        .buttonStyle(.link)
                        .padding(.top, 2)
                }
            }
        }
        .padding(10)
        .background(Color(nsColor: .controlBackgroundColor))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

struct OverviewTab: View {
    @ObservedObject var vm: ToolkitViewModel
    private let statusColumns = [
        GridItem(.flexible(), spacing: 6),
        GridItem(.flexible(), spacing: 6),
        GridItem(.flexible(), spacing: 6),
        GridItem(.flexible(), spacing: 6),
    ]
    private let actionColumns = [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8)]

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if vm.shouldShowUSBNetHelperBanner {
                HStack(alignment: .center, spacing: 10) {
                    Image(systemName: "lock.trianglebadge.exclamationmark")
                        .foregroundStyle(.orange)
                    VStack(alignment: .leading, spacing: 3) {
                        Text("主机网络权限未安装")
                            .font(.subheadline.weight(.semibold))
                        Text("未安装前，板子重启后 Mac 无法自动把 USB ECM 地址恢复到 198.19.77.2。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button("安装并修复") { vm.installUSBNetHelper() }
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 8)
                .background(Color.orange.opacity(0.12))
                .clipShape(RoundedRectangle(cornerRadius: 10))
            }

            LazyVGrid(columns: statusColumns, spacing: 6) {
                StatusCard(title: "USB 模式", value: vm.status?.usb?.mode ?? "-", ok: (vm.status?.usb?.mode ?? "") != "absent")
                StatusCard(title: "USB 设备", value: vm.status?.usb?.product ?? "-", ok: true)
                StatusCard(title: "主机网口", value: vm.status?.usbnet?.iface ?? "-", ok: vm.status?.usbnet?.configured == true)
                StatusCard(title: "主机 IP", value: vm.status?.usbnet?.current_ip ?? "-", ok: vm.status?.usbnet?.configured == true)
                StatusCard(title: "板卡 Ping", value: vm.status?.board?.ping == true ? "在线" : "离线", ok: vm.status?.board?.ping == true)
                StatusCard(title: "SSH", value: vm.status?.board?.ssh_port_open == true ? "可连接" : "未连接", ok: vm.status?.board?.ssh_port_open == true)
                StatusCard(title: "控制服务", value: vm.status?.board?.control_service == true ? "正常" : "未响应", ok: vm.status?.board?.control_service == true)
                StatusCard(title: "Docker", value: vm.status?.host?.docker_daemon == true ? "已就绪" : "未启动", ok: vm.status?.host?.docker_daemon == true)
            }

            GroupBox("连接与准备") {
                LazyVGrid(columns: actionColumns, spacing: 8) {
                    ActionTile(title: "主机预检", subtitle: "检查 Docker、镜像和刷机工具状态") { vm.checkHost() }
                    ActionTile(title: "恢复 USB 网络", subtitle: "修复 USB ECM 重枚举后的主机静态 IP") { vm.ensureUSBNet() }
                    ActionTile(title: "授权 SSH", subtitle: "把当前电脑公钥写入开发板") { vm.authorizeKey() }
                    ActionTile(title: "切换 Loader", subtitle: "通过 usb0 控制服务让开发板进入 Loader") { vm.rebootLoader() }
                }
                .padding(.top, 8)
            }
            Spacer(minLength: 0)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }
}

struct FlashTab: View {
    @ObservedObject var vm: ToolkitViewModel
    private let actionColumns = [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8)]

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            GroupBox("刷写镜像") {
                LazyVGrid(columns: actionColumns, spacing: 8) {
                    ActionTile(title: "刷写全部镜像", subtitle: "按 parameter.txt 刷写全部可匹配分区") { vm.flash("all") }
                    ActionTile(title: "仅刷 Boot", subtitle: "适合 logo 或 dtb 修改后的快速验证") { vm.flash("boot") }
                    ActionTile(title: "仅刷 Rootfs", subtitle: "适合系统服务、驱动和基础软件更新") { vm.flash("rootfs") }
                    ActionTile(title: "仅刷 Userdata", subtitle: "适合应用程序和资源文件更新") { vm.flash("userdata") }
                }
                .padding(.top, 8)
            }

            if vm.hasDevelopmentWorkspace {
                GroupBox("开发版流程") {
                    LazyVGrid(columns: actionColumns, spacing: 8) {
                        ActionTile(title: "构建并同步", subtitle: "执行开发版 build_and_sync") { vm.buildSync() }
                        ActionTile(title: "构建同步并刷写", subtitle: "执行开发版 build_sync_and_flash") { vm.buildSyncFlash() }
                    }
                    .padding(.top, 8)
                }
            }
            Spacer(minLength: 0)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }
}

struct InstallStatusRow: View {
    let title: String
    let detail: String
    let ok: Bool

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: ok ? "checkmark.circle.fill" : "circle.dashed")
                .foregroundStyle(ok ? .green : .secondary)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.subheadline.weight(.semibold))
                Text(detail)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .background(Color.primary.opacity(0.05))
        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
    }
}

struct ReleaseHeroCard: View {
    let symbol: String
    let title: String
    let subtitle: String
    let badgeText: String
    let badgeColor: Color

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(badgeColor.opacity(0.12))
                    .frame(width: 54, height: 54)
                Image(systemName: symbol)
                    .font(.system(size: 24, weight: .semibold))
                    .foregroundStyle(badgeColor)
            }
            VStack(alignment: .leading, spacing: 5) {
                Text(title)
                    .font(.title3.weight(.semibold))
                Text(subtitle)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Text(badgeText)
                .font(.caption.weight(.semibold))
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(badgeColor.opacity(0.12))
                .foregroundStyle(badgeColor)
                .clipShape(Capsule())
        }
        .padding(18)
        .background(
            LinearGradient(
                colors: [
                    Color.accentColor.opacity(0.10),
                    Color.primary.opacity(0.03)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

struct ReleaseStateCard: View {
    let title: String
    let detail: String
    let ok: Bool
    let helpText: String?
    let actionTitle: String?
    let action: (() -> Void)?
    let actionEnabled: Bool
    let actionEmphasized: Bool

    init(
        title: String,
        detail: String,
        ok: Bool,
        helpText: String? = nil,
        actionTitle: String? = nil,
        action: (() -> Void)? = nil,
        actionEnabled: Bool = true,
        actionEmphasized: Bool = false
    ) {
        self.title = title
        self.detail = detail
        self.ok = ok
        self.helpText = helpText
        self.actionTitle = actionTitle
        self.action = action
        self.actionEnabled = actionEnabled
        self.actionEmphasized = actionEmphasized
    }

    var tint: Color { ok ? .green : .secondary }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 8) {
                HStack(spacing: 8) {
                    Image(systemName: ok ? "checkmark.circle.fill" : "clock.badge.exclamationmark")
                        .foregroundStyle(tint)
                    Text(title)
                        .font(.subheadline.weight(.semibold))
                }
                Spacer()
                if let actionTitle, let action {
                    Button(actionTitle, action: action)
                        .buttonStyle(.plain)
                        .font(.caption.weight(.semibold))
                        .padding(.horizontal, actionEmphasized ? 12 : 0)
                        .padding(.vertical, actionEmphasized ? 7 : 0)
                        .background(
                            Group {
                                if actionEmphasized {
                                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                                        .fill(actionEnabled ? Color.accentColor : Color.secondary.opacity(0.18))
                                        .shadow(color: actionEnabled ? Color.black.opacity(0.18) : .clear, radius: 6, x: 0, y: 3)
                                }
                            }
                        )
                        .foregroundStyle(actionEmphasized ? Color.white : Color.accentColor)
                        .opacity(actionEnabled ? 1 : 0.6)
                        .disabled(!actionEnabled)
                }
            }
            Text(detail)
                .font(.caption2)
                .foregroundStyle(.secondary)
                .frame(maxWidth: .infinity, alignment: .leading)
                .lineLimit(2)
        }
        .padding(10)
        .frame(maxWidth: .infinity, minHeight: 64, maxHeight: 64, alignment: .leading)
        .background(Color.primary.opacity(0.045))
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .help(helpText ?? detail)
    }
}

struct ArtifactValidationRow: View {
    let item: LocalArtifactValidationItem

    var tint: Color {
        if item.ok {
            return item.optional ? .blue : .green
        }
        return .red
    }

    var symbol: String {
        if item.ok {
            return item.optional ? "checkmark.circle" : "checkmark.circle.fill"
        }
        return item.optional ? "minus.circle" : "xmark.octagon.fill"
    }

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: symbol)
                .foregroundStyle(tint)
            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 6) {
                    Text(item.title)
                        .font(.subheadline.weight(.semibold))
                    if item.optional {
                        Text("可选")
                            .font(.caption2.weight(.semibold))
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(Color.blue.opacity(0.12))
                            .foregroundStyle(.blue)
                            .clipShape(Capsule())
                    }
                }
                Text(item.detail)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
                    .truncationMode(.middle)
            }
            Spacer()
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .background(Color.primary.opacity(0.04))
        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
        .help(item.detail)
    }
}

struct InstallerPrimaryActionCard: View {
    let title: String
    let subtitle: String
    let primaryTitle: String
    let primaryAction: () -> Void
    let secondaryTitle: String
    let secondaryAction: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(title)
                .font(.headline)
            Text(subtitle)
                .font(.subheadline)
                .foregroundStyle(.secondary)

            HStack(spacing: 10) {
                Button(primaryTitle, action: primaryAction)
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                Button(secondaryTitle, action: secondaryAction)
                    .controlSize(.large)
            }
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.primary.opacity(0.035))
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

struct InstallerOfflineCard: View {
    let path: String
    let validation: LocalArtifactValidationState
    let chooseAction: () -> Void
    let installAction: () -> Void
    let detailAction: () -> Void

    private var summaryColor: Color {
        if validation.checking {
            return .secondary
        }
        if validation.ready {
            return .green
        }
        if validation.checked {
            return .red
        }
        return .secondary
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("离线安装")
                .font(.headline)
            Text("如已提前下载发布资源，可直接选择本地目录导入。")
                .font(.subheadline)
                .foregroundStyle(.secondary)

            HStack(spacing: 10) {
                Text(path.isEmpty ? "未选择本地安装包目录" : path)
                    .font(.caption)
                    .foregroundStyle(path.isEmpty ? .secondary : .primary)
                    .lineLimit(1)
                    .truncationMode(.middle)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 10)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(nsColor: .controlBackgroundColor))
                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                Button("选择目录", action: chooseAction)
                    .controlSize(.large)
            }

            HStack(spacing: 10) {
                Button("从本地文件安装", action: installAction)
                    .controlSize(.large)
                    .disabled(!validation.ready)
                Text("目录内应包含共享镜像、恢复镜像和发布工作区归档，Qt 编译环境包可选。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }

            HStack(spacing: 10) {
                Image(systemName: validation.ready ? "checkmark.seal.fill" : (validation.checked ? "exclamationmark.triangle.fill" : "folder.badge.questionmark"))
                    .foregroundStyle(summaryColor)
                Text(validation.summary)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(summaryColor)
                    .lineLimit(2)
                Spacer()
                if validation.checked && !validation.ready && !validation.failureDetail.isEmpty {
                    Button("查看详情", action: detailAction)
                        .controlSize(.small)
                }
                if validation.checking {
                    ProgressView()
                        .controlSize(.small)
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(Color.primary.opacity(0.04))
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
        .padding(18)
        .frame(maxWidth: .infinity, minHeight: 208, maxHeight: 208, alignment: .topLeading)
        .background(Color.primary.opacity(0.035))
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

struct ReleaseLogConsole: View {
    let title: String
    let statusText: String
    let running: Bool
    let progressValue: Double?
    let lines: [String]
    let logHeight: CGFloat
    let maxLines: Int

    private var visibleLines: [String] {
        Array(lines.suffix(maxLines))
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(.headline)
                    Text(statusText.isEmpty ? "等待操作" : statusText)
                        .font(.system(.subheadline, design: .monospaced).weight(.semibold))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                Spacer()
                if running {
                    ProgressView()
                        .controlSize(.small)
                }
            }

            if let progressValue {
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        ProgressView(value: progressValue, total: 1.0)
                            .progressViewStyle(.linear)
                        Text("\(Int(progressValue * 100))%")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.secondary)
                            .frame(width: 42, alignment: .trailing)
                    }
                }
            }

            ScrollView {
                VStack(alignment: .leading, spacing: 6) {
                    ForEach(Array(visibleLines.enumerated()), id: \.offset) { _, line in
                        Text(line)
                            .font(.system(.caption, design: .monospaced))
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(minHeight: logHeight, maxHeight: logHeight)
            .padding(12)
            .background(Color(nsColor: .textBackgroundColor))
            .foregroundStyle(Color.primary)
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(Color.primary.opacity(0.08), lineWidth: 1)
            )
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .padding(18)
        .frame(maxWidth: .infinity, minHeight: logHeight + 92, maxHeight: logHeight + 92, alignment: .topLeading)
        .background(Color.primary.opacity(0.03))
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

struct WindowAccessor: NSViewRepresentable {
    let onResolve: (NSWindow?) -> Void

    func makeNSView(context: Context) -> NSView {
        let view = NSView(frame: .zero)
        DispatchQueue.main.async {
            onResolve(view.window)
        }
        return view
    }

    func updateNSView(_ nsView: NSView, context: Context) {
        DispatchQueue.main.async {
            onResolve(nsView.window)
        }
    }
}

struct ToolkitInfoRowData: Identifiable {
    let id = UUID()
    let symbol: String
    let title: String
    let detail: String
    let tint: Color
}

struct ToolkitInfoSectionData: Identifiable {
    let id = UUID()
    let eyebrow: String
    let title: String
    let summary: String
    let rows: [ToolkitInfoRowData]
}

enum ToolkitInfoPage {
    case version(appVersion: String, buildVersion: String)
    case features
    case contact

    var windowTitle: String {
        switch self {
        case .version:
            return "版本信息"
        case .features:
            return "功能说明"
        case .contact:
            return "联系方式"
        }
    }

    var preferredSize: NSSize {
        switch self {
        case .version:
            return NSSize(width: 640, height: 620)
        case .features:
            return NSSize(width: 660, height: 720)
        case .contact:
            return NSSize(width: 560, height: 560)
        }
    }

    var accentColor: Color {
        switch self {
        case .version:
            return Color(red: 0.05, green: 0.45, blue: 0.78)
        case .features:
            return Color(red: 0.06, green: 0.55, blue: 0.38)
        case .contact:
            return Color(red: 0.80, green: 0.42, blue: 0.10)
        }
    }

    var heroTitle: String {
        switch self {
        case .version:
            return "RK356x Toolkit GUI"
        case .features:
            return "功能说明"
        case .contact:
            return "联系方式"
        }
    }

    var heroSubtitle: String {
        switch self {
        case .version:
            return "面向 RK356x 开发板的 macOS 常驻控制台，统一承载刷写、联机、发布与维护入口。"
        case .features:
            return "围绕 RK356x 的开发、刷写、发布和现场维护整理出的图形化能力入口。"
        case .contact:
            return "用于问题反馈、功能建议和维护支持的统一入口。欢迎通过邮箱联系，也可以通过下方二维码支持后续迭代。"
        }
    }

    var badgeText: String {
        switch self {
        case let .version(appVersion, buildVersion):
            return "v\(appVersion) · build \(buildVersion)"
        case .features:
            return "四类核心能力"
        case .contact:
            return "反馈与支持"
        }
    }

    var footerText: String {
        switch self {
        case .version:
            return "版本页用于查看当前安装包构建信息与工具覆盖范围。"
        case .features:
            return "功能页概览 GUI 已集成能力，具体执行入口仍在状态栏菜单和主面板中。"
        case .contact:
            return "感谢支持 RK356x Toolkit GUI。你的反馈和捐献都会直接用于后续维护、适配和体验优化。"
        }
    }

    var contactEmail: String? {
        switch self {
        case .contact:
            return "kong_w@foxmail.com"
        default:
            return nil
        }
    }

    var sections: [ToolkitInfoSectionData] {
        switch self {
        case let .version(appVersion, buildVersion):
            return [
                ToolkitInfoSectionData(
                    eyebrow: "当前构建",
                    title: "版本与运行形态",
                    summary: "当前安装包以状态栏应用运行，图形界面、本地控制服务和后台任务使用同一套执行链路。",
                    rows: [
                        ToolkitInfoRowData(
                            symbol: "app.badge.fill",
                            title: "应用版本",
                            detail: "当前 GUI 版本为 v\(appVersion)，构建号为 \(buildVersion)，适用于 macOS 14 及以上环境。",
                            tint: accentColor
                        ),
                        ToolkitInfoRowData(
                            symbol: "server.rack",
                            title: "控制服务 API",
                            detail: "内置本地控制服务 API v2，GUI、CLI 和异步任务共用同一条命令执行与状态回传路径。",
                            tint: Color.orange
                        ),
                        ToolkitInfoRowData(
                            symbol: "menubar.rectangle",
                            title: "工作方式",
                            detail: "常驻状态栏运行，支持后台状态监测、任务跟踪、更新安装和操作回显。",
                            tint: Color.purple
                        ),
                    ]
                ),
                ToolkitInfoSectionData(
                    eyebrow: "工具定位",
                    title: "覆盖场景",
                    summary: "这一版 GUI 重点覆盖 RK356x 在 macOS 下的连接管理、镜像刷写、开发联调和发布维护流程。",
                    rows: [
                        ToolkitInfoRowData(
                            symbol: "cable.connector",
                            title: "设备连接",
                            detail: "统一查看 USB、USB ECM、SSH、控制服务和 Docker 状态，减少多窗口切换。",
                            tint: Color.green
                        ),
                        ToolkitInfoRowData(
                            symbol: "externaldrive.badge.checkmark",
                            title: "刷写与恢复",
                            detail: "支持整机刷写，也支持 Boot、Rootfs、Userdata 的分区级快速验证。",
                            tint: Color.blue
                        ),
                        ToolkitInfoRowData(
                            symbol: "slider.horizontal.3",
                            title: "发布定制",
                            detail: "支持启动 Logo、设备树、恢复镜像资源与发布工作区管理。",
                            tint: Color.pink
                        ),
                    ]
                ),
            ]
        case .features:
            return [
                ToolkitInfoSectionData(
                    eyebrow: "监控与连接",
                    title: "统一状态总览",
                    summary: "把主机侧和板卡侧的关键连接状态收敛到一个常驻面板里，便于快速判断当前能执行什么操作。",
                    rows: [
                        ToolkitInfoRowData(
                            symbol: "dot.scope",
                            title: "连接状态",
                            detail: "实时展示 USB 模式、USB ECM 配置、开发板 Ping、SSH 端口和控制服务可达性。",
                            tint: Color.green
                        ),
                        ToolkitInfoRowData(
                            symbol: "shippingbox.circle",
                            title: "主机环境",
                            detail: "同时检查 Docker、共享镜像、rkflashtool 和发布资源是否准备完成。",
                            tint: Color.orange
                        ),
                        ToolkitInfoRowData(
                            symbol: "bell.badge",
                            title: "状态提醒",
                            detail: "连接变化、任务完成和异常情况会以界面提示或系统通知方式反馈。",
                            tint: Color.blue
                        ),
                    ]
                ),
                ToolkitInfoSectionData(
                    eyebrow: "刷写与定制",
                    title: "面向验证流程的快速操作",
                    summary: "针对开发和现场恢复最常见的动作做了图形化封装，降低命令行切换成本。",
                    rows: [
                        ToolkitInfoRowData(
                            symbol: "arrow.trianglehead.2.clockwise.rotate.90",
                            title: "整机与分区刷写",
                            detail: "支持按 parameter.txt 整机刷写，也支持 Boot、Rootfs、Userdata 的单独下发。",
                            tint: Color.red
                        ),
                        ToolkitInfoRowData(
                            symbol: "photo",
                            title: "启动 Logo 更新",
                            detail: "支持指定图片、旋转角度和显示比例，并可在更新后直接刷 Boot 分区。",
                            tint: Color.pink
                        ),
                        ToolkitInfoRowData(
                            symbol: "cpu",
                            title: "设备树更新",
                            detail: "支持选择 DTS 文件或目录进行增量更新，并联动 Boot 刷写验证。",
                            tint: Color.indigo
                        ),
                    ]
                ),
                ToolkitInfoSectionData(
                    eyebrow: "开发与发布",
                    title: "覆盖日常联调到交付准备",
                    summary: "把开发版构建同步、发布资源准备和插件安装收拢到 GUI 内，减少外部脚本依赖。",
                    rows: [
                        ToolkitInfoRowData(
                            symbol: "hammer",
                            title: "开发版流程",
                            detail: "支持 build and sync、build-sync-flash 等高频联调动作，适合快速验证迭代。",
                            tint: Color.orange
                        ),
                        ToolkitInfoRowData(
                            symbol: "shippingbox.fill",
                            title: "发布环境安装",
                            detail: "支持共享镜像、发布工作区、恢复镜像和辅助插件的准备与检查。",
                            tint: Color.green
                        ),
                        ToolkitInfoRowData(
                            symbol: "arrow.down.circle",
                            title: "软件与镜像更新",
                            detail: "支持软件更新检查、GUI 安装包替换和初始镜像资源同步。",
                            tint: Color.blue
                        ),
                    ]
                ),
                ToolkitInfoSectionData(
                    eyebrow: "后台能力",
                    title: "围绕稳定执行做的辅助机制",
                    summary: "GUI 不只是操作入口，还负责在后台维护本地服务、任务轮询和异常恢复。",
                    rows: [
                        ToolkitInfoRowData(
                            symbol: "clock.arrow.circlepath",
                            title: "异步任务跟踪",
                            detail: "长任务通过本地服务异步执行，窗口中持续展示进度、日志和完成状态。",
                            tint: Color.teal
                        ),
                        ToolkitInfoRowData(
                            symbol: "arrow.triangle.2.circlepath",
                            title: "自动更新联动",
                            detail: "更新完成后会自动切换到新安装包，并重新拉起应用实例。",
                            tint: Color.purple
                        ),
                        ToolkitInfoRowData(
                            symbol: "wrench.and.screwdriver",
                            title: "故障恢复",
                            detail: "遇到旧版本地服务或状态流异常时，会自动重启服务并恢复监控链路。",
                            tint: Color.gray
                        ),
                    ]
                ),
            ]
        case .contact:
            return [
                ToolkitInfoSectionData(
                    eyebrow: "联系作者",
                    title: "问题反馈与功能建议",
                    summary: "如果你在安装、刷写、联机调试或版本升级过程中遇到问题，或者希望补充新功能，可以直接通过邮箱联系。",
                    rows: [
                        ToolkitInfoRowData(
                            symbol: "envelope.badge.fill",
                            title: "联系邮箱",
                            detail: "kong_w@foxmail.com",
                            tint: accentColor
                        ),
                        ToolkitInfoRowData(
                            symbol: "bubble.left.and.bubble.right.fill",
                            title: "反馈内容建议",
                            detail: "建议附上当前版本、操作步骤、异常截图和日志信息，这样可以更快定位问题。",
                            tint: Color.blue
                        ),
                        ToolkitInfoRowData(
                            symbol: "hammer.circle.fill",
                            title: "维护支持",
                            detail: "如果这套工具对你的开发或交付流程有帮助，可以通过下方二维码支持后续维护与优化。",
                            tint: Color.green
                        ),
                    ]
                ),
            ]
        }
    }
}

struct ToolkitInfoLogoView: View {
    private var logoImage: NSImage? {
        guard let url = Bundle.main.url(forResource: "AppInfoLogo", withExtension: "png") else {
            return nil
        }
        return NSImage(contentsOf: url)
    }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(Color.white.opacity(0.72))
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .stroke(Color.white.opacity(0.85), lineWidth: 1)
            if let logoImage {
                Image(nsImage: logoImage)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .padding(18)
            } else {
                Image(systemName: "sparkles.rectangle.stack.fill")
                    .font(.system(size: 38, weight: .semibold))
                    .foregroundStyle(Color.accentColor)
            }
        }
        .frame(width: 116, height: 116)
        .shadow(color: Color.black.opacity(0.14), radius: 14, x: 0, y: 8)
    }
}

struct ToolkitInfoHeroCard: View {
    let page: ToolkitInfoPage

    var body: some View {
        HStack(spacing: 18) {
            VStack(alignment: .leading, spacing: 10) {
                Text(page.windowTitle)
                    .font(.system(.caption, design: .rounded).weight(.bold))
                    .foregroundStyle(page.accentColor)
                    .textCase(.uppercase)
                Text(page.heroTitle)
                    .font(.system(size: 30, weight: .bold, design: .rounded))
                Text(page.heroSubtitle)
                    .font(.system(.subheadline, design: .rounded))
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                Text(page.badgeText)
                    .font(.system(.caption, design: .rounded).weight(.semibold))
                    .padding(.horizontal, 12)
                    .padding(.vertical, 7)
                    .background(page.accentColor.opacity(0.12))
                    .foregroundStyle(page.accentColor)
                    .clipShape(Capsule())
            }
            Spacer(minLength: 0)
            ToolkitInfoLogoView()
        }
        .padding(22)
        .background(
            LinearGradient(
                colors: [
                    page.accentColor.opacity(0.18),
                    Color.primary.opacity(0.04),
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 26, style: .continuous)
                .strokeBorder(Color.white.opacity(0.45), lineWidth: 1)
        )
    }
}

struct ToolkitInfoRowCard: View {
    let row: ToolkitInfoRowData

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(row.tint.opacity(0.12))
                Image(systemName: row.symbol)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(row.tint)
            }
            .frame(width: 36, height: 36)

            VStack(alignment: .leading, spacing: 4) {
                Text(row.title)
                    .font(.system(.subheadline, design: .rounded).weight(.semibold))
                Text(row.detail)
                    .font(.system(.caption, design: .rounded))
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }
        .padding(14)
        .background(Color.primary.opacity(0.04))
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

struct ToolkitInfoSectionCard: View {
    let section: ToolkitInfoSectionData

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            VStack(alignment: .leading, spacing: 6) {
                Text(section.eyebrow)
                    .font(.system(.caption2, design: .rounded).weight(.bold))
                    .foregroundStyle(.secondary)
                    .textCase(.uppercase)
                Text(section.title)
                    .font(.system(.headline, design: .rounded).weight(.semibold))
                Text(section.summary)
                    .font(.system(.subheadline, design: .rounded))
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }

            VStack(spacing: 10) {
                ForEach(section.rows) { row in
                    ToolkitInfoRowCard(row: row)
                }
            }
        }
        .padding(18)
        .background(Color(nsColor: .controlBackgroundColor))
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
}

struct ToolkitBundledImageView: View {
    let resourceName: String
    let resourceExtension: String
    let fallbackSymbol: String

    private var image: NSImage? {
        guard let url = Bundle.main.url(forResource: resourceName, withExtension: resourceExtension) else {
            return nil
        }
        return NSImage(contentsOf: url)
    }

    var body: some View {
        Group {
            if let image {
                Image(nsImage: image)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            } else {
                Image(systemName: fallbackSymbol)
                    .font(.system(size: 44, weight: .semibold))
                    .foregroundStyle(.secondary)
            }
        }
    }
}

struct ToolkitContactEmailCard: View {
    let email: String
    let accentColor: Color
    @State private var didCopy = false

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 10) {
                Label("联系邮箱", systemImage: "envelope.fill")
                    .font(.system(.headline, design: .rounded).weight(.semibold))
                    .foregroundStyle(accentColor)

                Spacer()

                if didCopy {
                    Label("复制成功", systemImage: "checkmark.circle.fill")
                        .font(.system(.caption, design: .rounded).weight(.semibold))
                        .foregroundStyle(Color.green)
                        .transition(.move(edge: .trailing).combined(with: .opacity))
                }
            }

            Text(email)
                .font(.system(size: 20, weight: .bold, design: .rounded))
                .textSelection(.enabled)

            HStack(spacing: 10) {
                if let url = URL(string: "mailto:\(email)") {
                    Link(destination: url) {
                        Label("发送邮件", systemImage: "paperplane.fill")
                    }
                    .buttonStyle(.borderedProminent)
                }

                Button {
                    NSPasteboard.general.clearContents()
                    NSPasteboard.general.setString(email, forType: .string)
                    withAnimation(.easeOut(duration: 0.18)) {
                        didCopy = true
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.8) {
                        withAnimation(.easeOut(duration: 0.2)) {
                            didCopy = false
                        }
                    }
                } label: {
                    Label("复制邮箱", systemImage: "doc.on.doc")
                }
                .buttonStyle(.bordered)
            }
        }
        .padding(16)
        .background(
            LinearGradient(
                colors: [
                    accentColor.opacity(0.14),
                    Color.primary.opacity(0.035),
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
}

struct ToolkitDonationQRCodeCard: View {
    let title: String
    let subtitle: String
    let resourceName: String
    let resourceExtension: String
    let accentColor: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(title)
                    .font(.system(.headline, design: .rounded).weight(.semibold))
                Spacer()
                Text(subtitle)
                    .font(.system(.caption, design: .rounded).weight(.semibold))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(accentColor.opacity(0.12))
                    .foregroundStyle(accentColor)
                    .clipShape(Capsule())
            }

            ZStack {
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .fill(Color.white)
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(Color.black.opacity(0.06), lineWidth: 1)
                ToolkitBundledImageView(
                    resourceName: resourceName,
                    resourceExtension: resourceExtension,
                    fallbackSymbol: "qrcode"
                )
                .padding(16)
            }
            .frame(maxWidth: .infinity)
            .aspectRatio(1, contentMode: .fit)
        }
        .padding(14)
        .background(Color(nsColor: .controlBackgroundColor))
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
}

struct ToolkitDonationHintCard: View {
    let accentColor: Color

    var body: some View {
        VStack(spacing: 6) {
            Text("如果这套工具对你有帮助，欢迎捐赠支持 ☕️")
                .font(.system(.headline, design: .rounded).weight(.semibold))
                .multilineTextAlignment(.center)

            Text("你的支持会直接用于项目持续更新、功能打磨与体验优化 ❤️")
                .font(.system(.subheadline, design: .rounded))
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity)
        .padding(.horizontal, 18)
        .padding(.vertical, 14)
        .background(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .fill(accentColor.opacity(0.09))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(accentColor.opacity(0.12), lineWidth: 1)
        )
    }
}

struct ToolkitContactWindowView: View {
    let page: ToolkitInfoPage

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            if let email = page.contactEmail {
                ToolkitContactEmailCard(email: email, accentColor: page.accentColor)
            }

            ToolkitDonationHintCard(accentColor: page.accentColor)

            HStack(alignment: .top, spacing: 14) {
                ToolkitDonationQRCodeCard(
                    title: "支付宝",
                    subtitle: "Alipay",
                    resourceName: "ContactAlipay",
                    resourceExtension: "jpg",
                    accentColor: page.accentColor
                )
                ToolkitDonationQRCodeCard(
                    title: "微信",
                    subtitle: "WeChat",
                    resourceName: "ContactWeChat",
                    resourceExtension: "jpg",
                    accentColor: Color.green
                )
            }
        }
        .padding(18)
        .frame(
            minWidth: page.preferredSize.width,
            minHeight: page.preferredSize.height,
            alignment: .topLeading
        )
        .background(Color(nsColor: .windowBackgroundColor))
    }
}

struct ToolkitDonationPanel: View {
    let accentColor: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            VStack(alignment: .leading, spacing: 6) {
                Text("捐献支持")
                    .font(.system(.caption2, design: .rounded).weight(.bold))
                    .foregroundStyle(.secondary)
                    .textCase(.uppercase)
                Text("如果这套工具对你有帮助")
                    .font(.system(.headline, design: .rounded).weight(.semibold))
                Text("可以通过下面二维码支持后续维护与更新。两个二维码展示区域保持一致尺寸，便于快速扫码。")
                    .font(.system(.subheadline, design: .rounded))
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }

            HStack(alignment: .top, spacing: 16) {
                ToolkitDonationQRCodeCard(
                    title: "支付宝",
                    subtitle: "Alipay",
                    resourceName: "ContactAlipay",
                    resourceExtension: "jpg",
                    accentColor: accentColor
                )
                ToolkitDonationQRCodeCard(
                    title: "微信",
                    subtitle: "WeChat",
                    resourceName: "ContactWeChat",
                    resourceExtension: "jpg",
                    accentColor: Color.green
                )
            }
        }
        .padding(18)
        .background(Color(nsColor: .controlBackgroundColor))
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
}

struct ToolkitInfoWindowView: View {
    let page: ToolkitInfoPage

    var body: some View {
        Group {
            if case .contact = page {
                ToolkitContactWindowView(page: page)
            } else {
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        ToolkitInfoHeroCard(page: page)

                        ForEach(page.sections) { section in
                            ToolkitInfoSectionCard(section: section)
                        }

                        Text(page.footerText)
                            .font(.system(.caption, design: .rounded))
                            .foregroundStyle(.secondary)
                            .frame(maxWidth: .infinity, alignment: .center)
                            .padding(.top, 4)
                    }
                    .padding(.horizontal, 24)
                    .padding(.vertical, 22)
                }
            }
        }
        .frame(minWidth: page.preferredSize.width, minHeight: page.preferredSize.height)
        .background(Color(nsColor: .windowBackgroundColor))
    }
}

struct DevelopmentInstallWindowView: View {
    @ObservedObject var vm: ToolkitViewModel
    @State private var hostWindow: NSWindow?
    @State private var showLocalValidationDetail = false
    @State private var localValidationDetail = ""

    var installTaskVisible: Bool {
        vm.pendingTaskTitle.contains("发布环境全量安装") ||
            vm.pendingTaskTitle.contains("发布环境本地安装") ||
            vm.pendingTaskTitle.contains("Volume") ||
            vm.pendingTaskTitle.contains("镜像") ||
            vm.isInstallerTask(vm.currentTask)
    }

    var installTaskRunning: Bool {
        if !vm.pendingTaskTitle.isEmpty {
            return true
        }
        return vm.currentTask?.status != "finished" && vm.isInstallerTask(vm.currentTask)
    }

    private func syncWindowClosePolicy() {
        guard let hostWindow else {
            return
        }
        let allowClose = !installTaskRunning
        hostWindow.standardWindowButton(.closeButton)?.isEnabled = allowClose
        hostWindow.standardWindowButton(.miniaturizeButton)?.isEnabled = allowClose
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Color.clear
                .frame(height: 0)

            ReleaseHeroCard(
                symbol: "shippingbox.circle.fill",
                title: "发布环境安装",
                subtitle: "自动准备共享镜像、发布工作区和恢复镜像资源。",
                badgeText: vm.developmentInstallHeadline,
                badgeColor: vm.fullDevelopmentEnvironmentReady ? .green : .accentColor
            )

            HStack(spacing: 12) {
                ReleaseStateCard(
                    title: "运行环境",
                    detail: vm.developmentInstallStatus.dockerReady && vm.developmentInstallStatus.officialImageReady ? "Docker 与共享镜像已就绪" : "需要准备 Docker 和共享镜像",
                    ok: vm.developmentInstallStatus.dockerReady && vm.developmentInstallStatus.officialImageReady,
                    helpText: """
                    Docker Desktop: \(vm.developmentInstallStatus.dockerReady ? "已启动" : "未就绪")
                    共享镜像: \(vm.developmentInstallStatus.officialImageReady ? "已安装" : "未安装")
                    镜像名: \(vm.officialImageName)
                    """
                )
                ReleaseStateCard(
                    title: "发布工作区",
                    detail: vm.developmentInstallStatus.releaseVolumeReady ? "发布工作区 Volume 已可用" : "将自动导入发布工作区",
                    ok: vm.developmentInstallStatus.releaseVolumeReady,
                    helpText: """
                    Docker Volume: \(vm.officialVolumeName)
                    工作区模式: 发布版
                    """
                )
                ReleaseStateCard(
                    title: "恢复资源",
                    detail: vm.developmentInstallStatus.hostImagesReady && vm.developmentInstallStatus.rkflashtoolReady ? "恢复镜像与刷机工具已就绪" : "将自动导入恢复镜像并准备刷机工具",
                    ok: vm.developmentInstallStatus.hostImagesReady && vm.developmentInstallStatus.rkflashtoolReady,
                    helpText: """
                    镜像目录: \(vm.hostImageDirURL().path)
                    恢复镜像: \(vm.developmentInstallStatus.hostImagesReady ? "已就绪" : "未就绪")
                    rkflashtool-mac: \(vm.developmentInstallStatus.rkflashtoolReady ? "已就绪" : "未就绪")
                    """
                )
            }
            .padding(.top, 8)

            VStack(alignment: .leading, spacing: 10) {
                Text("AI 插件（可选）")
                    .font(.headline)
                HStack(spacing: 12) {
                    ReleaseStateCard(
                        title: "Codex 插件",
                        detail: vm.developmentInstallStatus.codexPluginInstalled ? "已安装，可直接在 Codex 中调用 RK356x 工具" : "未安装，可从当前应用直接安装",
                        ok: vm.developmentInstallStatus.codexPluginInstalled,
                        helpText: """
                        Codex 环境: \(vm.developmentInstallStatus.codexAvailable ? "已检测到" : "未检测到")
                        插件状态: \(vm.developmentInstallStatus.codexPluginInstalled ? "已安装" : "未安装")
                        """,
                        actionTitle: vm.developmentInstallStatus.codexPluginInstalled ? "重新安装" : "安装",
                        action: { vm.installCodexPlugin() },
                        actionEnabled: vm.developmentInstallStatus.codexAvailable,
                        actionEmphasized: true
                    )
                    ReleaseStateCard(
                        title: "OpenCode 插件",
                        detail: vm.developmentInstallStatus.openCodePluginInstalled ? "已安装，可直接在 OpenCode 中调用 RK356x 工具" : "未安装，可从当前应用直接安装",
                        ok: vm.developmentInstallStatus.openCodePluginInstalled,
                        helpText: """
                        OpenCode 环境: \(vm.developmentInstallStatus.openCodeAvailable ? "已检测到" : "未检测到")
                        npm: \(vm.developmentInstallStatus.npmReady ? "已检测到" : "未检测到")
                        插件状态: \(vm.developmentInstallStatus.openCodePluginInstalled ? "已安装" : "未安装")
                        """,
                        actionTitle: vm.developmentInstallStatus.openCodePluginInstalled ? "重新安装" : "安装",
                        action: { vm.installOpenCodePlugin() },
                        actionEnabled: vm.developmentInstallStatus.openCodeAvailable && vm.developmentInstallStatus.npmReady,
                        actionEmphasized: true
                    )
                }
            }
            .padding(.top, 4)

            HStack {
                Spacer()
                Button("重新检查") {
                    Task { await vm.refreshDevelopmentInstallStatus() }
                }
                .controlSize(.large)
            }

            InstallerOfflineCard(
                path: vm.localArtifactsDir,
                validation: vm.localArtifactValidation,
                chooseAction: { vm.browseDirectory { path in
                    vm.localArtifactsDir = path
                    vm.validateLocalArtifactsDirectory(showFailureDetails: true)
                } },
                installAction: { vm.installFullDevelopmentEnvironmentFromLocal() },
                detailAction: {
                    localValidationDetail = vm.localArtifactValidation.failureDetail
                    showLocalValidationDetail = true
                }
            )

            Spacer(minLength: 0)
        }
        .padding(.horizontal, 22)
        .padding(.top, 14)
        .padding(.bottom, 18)
        .frame(minWidth: 760, minHeight: 580)
        .background(
            WindowAccessor { window in
                hostWindow = window
                syncWindowClosePolicy()
            }
        )
        .overlay {
            if installTaskVisible {
                TaskOverlayView(vm: vm)
            }
        }
        .sheet(isPresented: $showLocalValidationDetail) {
            VStack(alignment: .leading, spacing: 12) {
                Text("校验详情")
                    .font(.title3.weight(.semibold))
                ScrollView {
                    Text(localValidationDetail)
                        .font(.system(.body, design: .monospaced))
                        .textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                HStack {
                    Spacer()
                    Button("关闭") {
                        showLocalValidationDetail = false
                    }
                }
            }
            .padding(20)
            .frame(minWidth: 560, minHeight: 320)
        }
        .onAppear {
            syncWindowClosePolicy()
        }
        .onChange(of: installTaskVisible) { _, _ in
            syncWindowClosePolicy()
        }
        .onChange(of: vm.currentTask?.status) { _, _ in
            syncWindowClosePolicy()
        }
        .onChange(of: vm.localArtifactValidation) { _, state in
            if state.checked, !state.ready, !state.failureDetail.isEmpty {
                localValidationDetail = state.failureDetail
                showLocalValidationDetail = true
            }
        }
        .task {
            if !vm.localArtifactsDir.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                vm.validateLocalArtifactsDirectory()
            }
            while !Task.isCancelled {
                await vm.refreshDevelopmentInstallStatus()
                try? await Task.sleep(for: .seconds(3))
            }
        }
    }
}

struct ToolkitUpdateWindowView: View {
    @ObservedObject var vm: ToolkitViewModel

    var updateTaskVisible: Bool {
        vm.pendingTaskTitle == "软件更新" ||
            vm.pendingTaskTitle == "初始镜像更新" ||
            vm.isUpdaterTask(vm.currentTask)
    }

    var updateFlowRunning: Bool {
        updateTaskVisible || vm.automaticToolkitUpdateInProgress
    }

    var statusText: String {
        if updateTaskVisible {
            return vm.taskProgressLine(for: vm.currentTask)
        }
        return vm.updaterLastDetail
    }

    var logLines: [String] {
        if updateTaskVisible {
            return vm.taskTimelineLines(for: vm.currentTask)
        }
        return Array(vm.updaterLastDetail
            .split(separator: "\n")
            .map(String.init)
            .suffix(4))
    }

    var displayText: String {
        if updateFlowRunning {
            return statusText.isEmpty ? "正在联网检查更新..." : statusText
        }
        if !vm.updateConfigured {
            return "未配置远程更新地址"
        }
        if !vm.toolkitUpdateStatus.remoteVersion.isEmpty {
            return "当前版本 \(vm.toolkitUpdateStatus.currentVersion)，已经是最新版本"
        }
        return "等待检查更新"
    }

    var body: some View {
        VStack(spacing: 16) {
            Spacer(minLength: 0)

            if let progress = vm.taskProgressValue(for: vm.currentTask), updateFlowRunning {
                ProgressView(value: progress)
                    .progressViewStyle(.linear)
                    .frame(width: 320)
            } else if updateFlowRunning {
                ProgressView()
                    .progressViewStyle(.linear)
                    .frame(width: 320)
            }

            Text(displayText)
                .font(.subheadline)
                .multilineTextAlignment(.center)
                .frame(maxWidth: .infinity)

            Spacer(minLength: 0)
        }
        .padding(.horizontal, 24)
        .padding(.vertical, 20)
        .frame(minWidth: 420, minHeight: 150)
        .task {
            vm.startAutomaticToolkitUpdateFlow()
        }
    }
}

struct CustomizeTab: View {
    @ObservedObject var vm: ToolkitViewModel
    private let rotateOptions = ["-90", "0", "90", "180"]

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            GroupBox("启动 Logo") {
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text(vm.logoPath.isEmpty ? "未选择 logo 文件" : vm.logoPath)
                            .lineLimit(1)
                            .truncationMode(.middle)
                            .foregroundStyle(vm.logoPath.isEmpty ? .secondary : .primary)
                        Spacer()
                        Button("选择文件") { vm.browseFile { vm.logoPath = $0 } }
                    }
                    HStack {
                        Text("旋转角度")
                        Picker("旋转角度", selection: $vm.logoRotate) {
                            ForEach(rotateOptions, id: \.self) { option in
                                Text(option).tag(option)
                            }
                        }
                        .labelsHidden()
                        .frame(width: 92)
                        Text("比例")
                        TextField("100", text: $vm.logoScale)
                            .textFieldStyle(.roundedBorder)
                            .frame(width: 70)
                        Text("%")
                            .foregroundStyle(.secondary)
                        Spacer()
                    }
                    Toggle("更新后直接刷 Boot", isOn: $vm.logoFlashAfter)
                    HStack {
                        Spacer()
                        Button("执行 Logo 更新") { vm.updateLogo() }
                    }
                }
                .padding(.top, 8)
            }

            GroupBox("设备树") {
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text(vm.dtsFilePath.isEmpty ? "未选择设备树文件" : vm.dtsFilePath)
                            .lineLimit(1)
                            .truncationMode(.middle)
                            .foregroundStyle(vm.dtsFilePath.isEmpty ? .secondary : .primary)
                        Spacer()
                        Button("选择文件") { vm.browseFile { vm.dtsFilePath = $0 } }
                    }
                    HStack {
                        Toggle("更新后直接刷 Boot", isOn: $vm.dtsFlashAfter)
                        Spacer()
                        Button("执行设备树更新") { vm.updateDTB() }
                    }
                }
                .padding(.top, 8)
            }
            Spacer(minLength: 0)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }
}

struct ActivityTab: View {
    @ObservedObject var vm: ToolkitViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if let entry = vm.selectedActivityEntry {
                HStack {
                    Button {
                        vm.selectedActivityEntry = nil
                    } label: {
                        Label("返回列表", systemImage: "chevron.left")
                    }
                    .buttonStyle(.plain)
                    Spacer()
                    Text(entry.timestamp.formatted(date: .omitted, time: .standard))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                VStack(alignment: .leading, spacing: 8) {
                    Label(entry.title, systemImage: entry.level.symbol)
                        .font(.headline)
                        .foregroundStyle(entry.level.color)
                    Text(entry.message)
                        .font(.subheadline)
                    ScrollView {
                        Text(entry.detail ?? entry.message)
                            .font(.system(.caption, design: .monospaced))
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    .padding(10)
                    .background(Color(nsColor: .controlBackgroundColor))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                }
            } else {
                if vm.activities.isEmpty {
                    Text("暂无活动记录")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(Array(vm.activities.prefix(4))) { entry in
                        ActivityRow(entry: entry) {
                            vm.selectedActivityEntry = entry
                        }
                    }
                }
            }
            Spacer(minLength: 0)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }
}

struct TaskOverlayView: View {
    @ObservedObject var vm: ToolkitViewModel

    var title: String {
        if vm.postFlashRecoveryActive {
            return vm.postFlashRecoveryTitle
        }
        if let task = vm.currentTask {
            return task.action ?? "后台任务"
        }
        return vm.pendingTaskTitle.isEmpty ? "后台任务" : vm.pendingTaskTitle
    }

    var isRunning: Bool {
        if vm.postFlashRecoveryActive {
            return !vm.postFlashRecoveryFinished
        }
        if !vm.pendingTaskTitle.isEmpty {
            return true
        }
        return vm.currentTask?.status != "finished"
    }

    var statusText: String {
        if vm.postFlashRecoveryActive {
            return vm.postFlashRecoveryStatus
        }
        return vm.taskStatusText(for: vm.currentTask)
    }

    var progressText: String {
        if vm.postFlashRecoveryActive {
            return vm.postFlashRecoveryProgress
        }
        return vm.taskProgressLine(for: vm.currentTask)
    }

    var detailLines: [String] {
        if vm.postFlashRecoveryActive {
            return vm.postFlashRecoveryLines
        }
        return vm.taskTimelineLines(for: vm.currentTask)
    }

    var progressValue: Double? {
        if vm.postFlashRecoveryActive {
            return vm.postFlashRecoveryProgressValue
        }
        return vm.taskProgressValue(for: vm.currentTask)
    }

    var statusColor: Color {
        if vm.postFlashRecoveryActive {
            if isRunning {
                return .orange
            }
            return vm.postFlashRecoverySucceeded ? .green : .red
        }
        return isRunning ? .orange : (vm.currentTask?.ok == true ? .green : .red)
    }

    var body: some View {
        ZStack {
            Color.black.opacity(0.18)
                .ignoresSafeArea()

            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(title)
                            .font(.headline)
                        if !statusText.isEmpty {
                            Text(statusText)
                                .font(.caption)
                                .foregroundStyle(statusColor)
                        }
                    }
                    Spacer()
                    if isRunning {
                        ProgressView()
                            .controlSize(.small)
                    }
                }

                VStack(alignment: .leading, spacing: 10) {
                    if let progressValue, isRunning {
                        ProgressView(value: progressValue)
                            .progressViewStyle(.linear)
                    }
                    Text(progressText)
                        .font(.system(.subheadline, design: .monospaced).weight(.semibold))
                        .foregroundStyle(.primary)
                        .lineLimit(1)

                    VStack(alignment: .leading, spacing: 6) {
                        ForEach(Array(detailLines.prefix(5).enumerated()), id: \.offset) { _, line in
                            Text(line)
                                .font(.system(.caption, design: .monospaced))
                                .textSelection(.enabled)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }
                    .frame(maxWidth: .infinity, minHeight: 132, maxHeight: 132, alignment: .topLeading)
                }
                .padding(10)
                .background(Color(nsColor: .controlBackgroundColor))
                .clipShape(RoundedRectangle(cornerRadius: 10))

                HStack {
                    Spacer()
                    if !isRunning {
                        Button("关闭") { vm.dismissCurrentTaskOverlay() }
                    }
                }
            }
            .padding(16)
            .frame(width: 430)
            .background(Color(nsColor: .windowBackgroundColor))
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .shadow(radius: 18)
        }
    }
}

struct ContentView: View {
    @ObservedObject var vm: ToolkitViewModel
    @State private var selectedTab = 0

    var footerMessage: String {
        vm.inlineErrorMessage.isEmpty ? vm.lastActionSummary : vm.inlineErrorMessage
    }

    var footerIsError: Bool {
        !vm.inlineErrorMessage.isEmpty
    }

    var body: some View {
        ZStack {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("RK356x 工具")
                            .font(.headline)
                        Text(vm.statusHeadline)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    if vm.busy && !vm.taskOverlayVisible {
                        ProgressView()
                            .controlSize(.small)
                    }
                }
                .padding(.top, 36)
                .padding(.bottom, 4)

                HStack(spacing: 8) {
                    HStack(spacing: 0) {
                        Button {
                            vm.switchWorkspaceMode(.release)
                        } label: {
                            Label("发布版", systemImage: WorkspaceMode.release.symbolName)
                                .font(.caption)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 5)
                                .frame(minWidth: 82)
                                .background(vm.workspaceMode == .release ? Color.accentColor.opacity(0.18) : .clear)
                                .foregroundStyle(vm.workspaceMode == .release ? Color.accentColor : .secondary)
                        }
                        .buttonStyle(.plain)

                        if vm.hasDevelopmentWorkspace {
                            Divider()
                                .frame(height: 18)

                            Button {
                                vm.switchWorkspaceMode(.development)
                            } label: {
                                Label("开发版", systemImage: WorkspaceMode.development.symbolName)
                                    .font(.caption)
                                    .padding(.horizontal, 10)
                                    .padding(.vertical, 5)
                                    .frame(minWidth: 82)
                                    .background(vm.workspaceMode == .development ? Color.accentColor.opacity(0.18) : .clear)
                                    .foregroundStyle(vm.workspaceMode == .development ? Color.accentColor : .secondary)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .background(Color.primary.opacity(0.06))
                    .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))

                    Spacer()
                    Text(vm.serviceRunning ? "本地服务在线" : "本地服务离线")
                        .font(.caption)
                        .foregroundStyle(vm.serviceRunning ? .green : .secondary)
                    Text(vm.lastUpdatedText)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                    Button("设备重启") { vm.rebootDevice() }
                }

                Picker("", selection: $selectedTab) {
                    Text("总览").tag(0)
                    Text("刷写").tag(1)
                    Text("定制").tag(2)
                    Text("通知").tag(3)
                }
                .pickerStyle(.segmented)

                Group {
                    if selectedTab == 0 {
                        OverviewTab(vm: vm)
                    } else if selectedTab == 1 {
                        FlashTab(vm: vm)
                    } else if selectedTab == 2 {
                        CustomizeTab(vm: vm)
                    } else {
                        ActivityTab(vm: vm)
                    }
                }
                .frame(maxWidth: .infinity, minHeight: 334, maxHeight: .infinity, alignment: .topLeading)

                HStack(alignment: .center, spacing: 8) {
                    if footerIsError {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .foregroundStyle(vm.footerFlashOn ? .orange : .red)
                    }
                    Text(footerMessage)
                        .font(.caption)
                        .lineLimit(2)
                        .foregroundStyle(footerIsError ? (vm.footerFlashOn ? .orange : .red) : .secondary)
                    Spacer()
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 8)
                .frame(maxWidth: .infinity, minHeight: 44, maxHeight: 44, alignment: .center)
                .padding(.top, 8)
                .padding(.bottom, 10)
                .offset(y: -20)
            }
            .padding(.horizontal, 14)
            .padding(.top, 18)
            .padding(.bottom, 14)
            .frame(width: 520, height: 500)
            .background(Color(nsColor: .windowBackgroundColor))
            .allowsHitTesting(!vm.taskOverlayBlocking)

            if vm.taskOverlayVisible {
                TaskOverlayView(vm: vm)
            }
        }
    }
}

@MainActor
final class WindowCloseGuard: NSObject, NSWindowDelegate {
    let canClose: () -> Bool

    init(canClose: @escaping () -> Bool) {
        self.canClose = canClose
    }

    func windowShouldClose(_ sender: NSWindow) -> Bool {
        canClose()
    }
}

@MainActor
final class StatusBarController: NSObject, NSPopoverDelegate {
    private let vm: ToolkitViewModel
    private let statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
    private let popover = NSPopover()
    private let contextMenu = NSMenu()
    private var versionInfoWindowController: NSWindowController?
    private var featureInfoWindowController: NSWindowController?
    private var contactInfoWindowController: NSWindowController?
    private var developmentInstallWindowController: NSWindowController?
    private var developmentInstallWindowCloseGuard: WindowCloseGuard?
    private var updateWindowController: NSWindowController?
    private var cancellables = Set<AnyCancellable>()
    private var appearanceObserver: NSObjectProtocol?
    private var globalClickMonitor: Any?
    private var localClickMonitor: Any?

    init(vm: ToolkitViewModel) {
        self.vm = vm
        super.init()
        configurePopover()
        configureMenu()
        configureStatusItem()
        bindViewModel()
        updateStatusItemAppearance()
    }

    deinit {
        if let appearanceObserver {
            DistributedNotificationCenter.default().removeObserver(appearanceObserver)
        }
        if let globalClickMonitor {
            NSEvent.removeMonitor(globalClickMonitor)
        }
        if let localClickMonitor {
            NSEvent.removeMonitor(localClickMonitor)
        }
    }

    private func configurePopover() {
        popover.behavior = .applicationDefined
        popover.contentSize = NSSize(width: 520, height: 500)
        popover.contentViewController = NSHostingController(rootView: ContentView(vm: vm))
        popover.delegate = self
    }

    private func configureMenu() {
        let versionItem = NSMenuItem(title: "版本信息", action: #selector(showVersionInfo), keyEquivalent: "")
        versionItem.target = self
        contextMenu.addItem(versionItem)

        let featureItem = NSMenuItem(title: "功能说明", action: #selector(showFeatureInfo), keyEquivalent: "")
        featureItem.target = self
        contextMenu.addItem(featureItem)

        let contactItem = NSMenuItem(title: "联系方式", action: #selector(showContactInfo), keyEquivalent: "")
        contactItem.target = self
        contextMenu.addItem(contactItem)

        let installItem = NSMenuItem(title: "发布环境安装", action: #selector(showDevelopmentInstallWindow), keyEquivalent: "")
        installItem.target = self
        contextMenu.addItem(installItem)

        let updateItem = NSMenuItem(title: "软件更新", action: #selector(showUpdateWindow), keyEquivalent: "")
        updateItem.target = self
        contextMenu.addItem(updateItem)

        contextMenu.addItem(.separator())

        let quitItem = NSMenuItem(title: "退出", action: #selector(quitApp), keyEquivalent: "q")
        quitItem.target = self
        contextMenu.addItem(quitItem)
    }

    private func configureStatusItem() {
        guard let button = statusItem.button else {
            return
        }
        button.target = self
        button.action = #selector(handleStatusItemClick(_:))
        button.sendAction(on: [.leftMouseUp, .rightMouseUp])
        appearanceObserver = DistributedNotificationCenter.default().addObserver(
            forName: Notification.Name("AppleInterfaceThemeChangedNotification"),
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in
                self?.updateStatusItemAppearance()
            }
        }
    }

    private func bindViewModel() {
        Publishers.CombineLatest(vm.$status, vm.$serviceRunning)
            .receive(on: RunLoop.main)
            .sink { [weak self] _, _ in
                self?.updateStatusItemAppearance()
            }
            .store(in: &cancellables)
    }

    private func installClickMonitors() {
        if globalClickMonitor == nil {
            globalClickMonitor = NSEvent.addGlobalMonitorForEvents(matching: [.leftMouseDown, .rightMouseDown]) { [weak self] event in
                Task { @MainActor in
                    self?.handleOutsideClick(event)
                }
            }
        }
        if localClickMonitor == nil {
            localClickMonitor = NSEvent.addLocalMonitorForEvents(matching: [.leftMouseDown, .rightMouseDown]) { [weak self] event in
                guard let self else {
                    return event
                }
                self.handleOutsideClick(event)
                return event
            }
        }
    }

    private func shouldKeepPopoverOpen(for event: NSEvent) -> Bool {
        guard popover.isShown else {
            return true
        }

        if vm.fileDialogActive {
            return true
        }

        if let popoverWindow = popover.contentViewController?.view.window {
            if event.window === popoverWindow {
                return true
            }
            if popoverWindow.frame.contains(NSEvent.mouseLocation) {
                return true
            }
        }

        if let button = statusItem.button, let buttonWindow = button.window {
            let buttonRect = button.convert(button.bounds, to: nil)
            let buttonScreenRect = buttonWindow.convertToScreen(buttonRect)
            if buttonScreenRect.contains(NSEvent.mouseLocation) {
                return true
            }
        }

        return false
    }

    private func handleOutsideClick(_ event: NSEvent) {
        guard popover.isShown else {
            return
        }
        if shouldKeepPopoverOpen(for: event) {
            return
        }
        closePopover()
    }

    private func tintColor() -> NSColor {
        if !vm.serviceRunning {
            return .systemOrange
        }
        switch vm.status?.usb?.mode ?? "absent" {
        case "loader":
            return .systemBlue
        case "usb-ecm":
            return vm.status?.board?.ping == true ? .systemGreen : .systemOrange
        case "absent":
            return .secondaryLabelColor
        default:
            return .systemOrange
        }
    }

    private func updateStatusItemAppearance() {
        guard let button = statusItem.button else {
            return
        }
        button.image = makeStatusBarImage(for: button)
        button.imageScaling = .scaleProportionallyUpOrDown
        button.contentTintColor = nil
        button.title = ""
        button.toolTip = vm.statusHeadline
    }

    private func iconPrimaryColor(for button: NSStatusBarButton) -> NSColor {
        let match = button.effectiveAppearance.bestMatch(from: [.darkAqua, .aqua])
        return match == .darkAqua ? .white : .black
    }

    private func makeStatusBarImage(for button: NSStatusBarButton) -> NSImage? {
        let canvasSize = NSSize(width: 24, height: 24)
        let composite = NSImage(size: canvasSize)
        composite.lockFocus()
        defer {
            composite.unlockFocus()
        }
        let primaryColor = iconPrimaryColor(for: button)
        primaryColor.setStroke()
        primaryColor.setFill()

        let tabletRect = NSRect(x: 2.1, y: 5.0, width: 15.6, height: 12.0)
        let tablet = NSBezierPath(roundedRect: tabletRect, xRadius: 2.4, yRadius: 2.4)
        tablet.lineWidth = 1.9
        tablet.stroke()

        let screenRect = NSRect(x: 4.4, y: 6.8, width: 11.8, height: 8.4)
        let screen = NSBezierPath(roundedRect: screenRect, xRadius: 1.1, yRadius: 1.1)
        screen.lineWidth = 1.2
        screen.stroke()

        let touchPoint = NSBezierPath(ovalIn: NSRect(x: 9.8, y: 9.5, width: 2.1, height: 2.1))
        touchPoint.fill()

        let cable = NSBezierPath()
        cable.lineWidth = 1.9
        cable.lineCapStyle = .round
        cable.move(to: NSPoint(x: 17.7, y: 10.7))
        cable.curve(
            to: NSPoint(x: 22.2, y: 6.2),
            controlPoint1: NSPoint(x: 19.6, y: 10.7),
            controlPoint2: NSPoint(x: 20.8, y: 8.0)
        )
        cable.stroke()

        let plug = NSBezierPath(roundedRect: NSRect(x: 20.7, y: 4.9, width: 2.1, height: 2.4), xRadius: 0.6, yRadius: 0.6)
        plug.fill()

        let statusDot = NSBezierPath(ovalIn: NSRect(x: 17.5, y: 16.6, width: 4.0, height: 4.0))
        tintColor().setFill()
        statusDot.fill()

        composite.isTemplate = false
        return composite
    }

    private func showPopover() {
        guard let button = statusItem.button else {
            return
        }
        installClickMonitors()
        popover.contentSize = NSSize(width: 520, height: 500)
        if let hosting = popover.contentViewController as? NSHostingController<ContentView> {
            hosting.rootView = ContentView(vm: vm)
        }
        popover.show(relativeTo: button.bounds, of: button, preferredEdge: .minY)
        popover.contentViewController?.view.window?.makeKey()
    }

    private func closePopover() {
        popover.performClose(nil)
    }

    @objc private func handleStatusItemClick(_ sender: Any?) {
        guard let event = NSApp.currentEvent else {
            togglePopover()
            return
        }
        if event.type == .rightMouseUp {
            closePopover()
            statusItem.menu = contextMenu
            statusItem.button?.performClick(nil)
            statusItem.menu = nil
        } else {
            togglePopover()
        }
    }

    private func togglePopover() {
        if popover.isShown {
            closePopover()
        } else {
            showPopover()
        }
    }

    @objc private func quitApp() {
        NSApplication.shared.terminate(nil)
    }

    private func presentInfoWindow(page: ToolkitInfoPage) {
        let existingController: NSWindowController? = {
            switch page {
            case .version:
                return versionInfoWindowController
            case .features:
                return featureInfoWindowController
            case .contact:
                return contactInfoWindowController
            }
        }()

        if let existingController {
            existingController.showWindow(nil)
            existingController.window?.makeKeyAndOrderFront(nil)
            NSApp.activate(ignoringOtherApps: true)
            return
        }

        let preferredSize = page.preferredSize
        let window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: preferredSize.width, height: preferredSize.height),
            styleMask: [.titled, .closable, .miniaturizable],
            backing: .buffered,
            defer: false
        )
        window.title = page.windowTitle
        window.center()
        window.setContentSize(preferredSize)
        window.contentViewController = NSHostingController(rootView: ToolkitInfoWindowView(page: page))

        let controller = NSWindowController(window: window)
        switch page {
        case .version:
            versionInfoWindowController = controller
        case .features:
            featureInfoWindowController = controller
        case .contact:
            contactInfoWindowController = controller
        }
        controller.showWindow(nil)
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)

        NotificationCenter.default.addObserver(
            forName: NSWindow.willCloseNotification,
            object: window,
            queue: .main
        ) { [weak self, weak window] _ in
            Task { @MainActor [weak self, weak window] in
                guard let self, window != nil else {
                    return
                }
                switch page {
                case .version:
                    self.versionInfoWindowController = nil
                case .features:
                    self.featureInfoWindowController = nil
                case .contact:
                    self.contactInfoWindowController = nil
                }
            }
        }
    }

    @objc private func showVersionInfo() {
        let shortVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.0"
        let buildVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "1"
        presentInfoWindow(page: .version(appVersion: shortVersion, buildVersion: buildVersion))
    }

    @objc private func showFeatureInfo() {
        presentInfoWindow(page: .features)
    }

    @objc private func showContactInfo() {
        presentInfoWindow(page: .contact)
    }

    @objc private func showDevelopmentInstallWindow() {
        if let controller = developmentInstallWindowController {
            controller.showWindow(nil)
            controller.window?.makeKeyAndOrderFront(nil)
            NSApp.activate(ignoringOtherApps: true)
            Task { await vm.refreshDevelopmentInstallStatus() }
            return
        }

        let window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 760, height: 540),
            styleMask: [.titled, .closable, .miniaturizable],
            backing: .buffered,
            defer: false
        )
        window.title = "RK356x 发布环境安装"
        window.center()
        window.setContentSize(NSSize(width: 760, height: 540))
        let closeGuard = WindowCloseGuard { [weak vm] in
            guard let vm else {
                return true
            }
            if !vm.pendingTaskTitle.isEmpty {
                return false
            }
            if let task = vm.currentTask, vm.isInstallerTask(task), task.status != "finished" {
                return false
            }
            return true
        }
        developmentInstallWindowCloseGuard = closeGuard
        window.delegate = closeGuard
        window.contentViewController = NSHostingController(rootView: DevelopmentInstallWindowView(vm: vm))

        let controller = NSWindowController(window: window)
        developmentInstallWindowController = controller
        controller.showWindow(nil)
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        Task { await vm.refreshDevelopmentInstallStatus() }

        NotificationCenter.default.addObserver(
            forName: NSWindow.willCloseNotification,
            object: window,
            queue: .main
        ) { [weak self, weak window] _ in
            Task { @MainActor [weak self, weak window] in
                guard let self, window === self.developmentInstallWindowController?.window else {
                    return
                }
                self.developmentInstallWindowController = nil
                self.developmentInstallWindowCloseGuard = nil
            }
        }
    }

    @objc private func showUpdateWindow() {
        vm.refreshToolkitUpdateStatus()
        if let controller = updateWindowController {
            controller.showWindow(nil)
            controller.window?.makeKeyAndOrderFront(nil)
            NSApp.activate(ignoringOtherApps: true)
            vm.startAutomaticToolkitUpdateFlow()
            return
        }

        let window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 420, height: 170),
            styleMask: [.titled, .closable, .miniaturizable],
            backing: .buffered,
            defer: false
        )
        window.title = "RK356x 软件更新"
        window.center()
        window.setContentSize(NSSize(width: 420, height: 170))
        window.contentViewController = NSHostingController(rootView: ToolkitUpdateWindowView(vm: vm))

        let controller = NSWindowController(window: window)
        updateWindowController = controller
        controller.showWindow(nil)
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        vm.startAutomaticToolkitUpdateFlow()

        NotificationCenter.default.addObserver(
            forName: NSWindow.willCloseNotification,
            object: window,
            queue: .main
        ) { [weak self, weak window] _ in
            Task { @MainActor [weak self, weak window] in
                guard let self, window === self.updateWindowController?.window else {
                    return
                }
                self.updateWindowController = nil
            }
        }
    }
}

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate {
    private let vm = ToolkitViewModel()
    private var statusBarController: StatusBarController?

    func applicationDidFinishLaunching(_ notification: Notification) {
        vm.startBackgroundMonitoring()
        vm.startGUITelemetrySession()
        statusBarController = StatusBarController(vm: vm)
    }

    func applicationWillTerminate(_ notification: Notification) {
        vm.stopGUITelemetrySessionSync(reason: "app-terminate")
    }
}

@main
struct RK356xToolkitGUIApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate

    var body: some Scene {
        Settings {
            EmptyView()
        }
    }
}
