#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
BUILD_DIR="${SCRIPT_DIR}/build"
APP_NAME="RK356xToolkitGUI"
APP_DIR="${BUILD_DIR}/${APP_NAME}.app"
BIN_DIR="${APP_DIR}/Contents/MacOS"
RES_DIR="${APP_DIR}/Contents/Resources"
BIN_PATH="${BIN_DIR}/${APP_NAME}"
RUNTIME_DIR="${RES_DIR}/toolkit-runtime"
ICON_SOURCE="${REPO_ROOT}/logo_Image.png"
INFO_LOGO_SOURCE="${REPO_ROOT}/assets/app-logo.png"
ALIPAY_QR_SOURCE="${REPO_ROOT}/assets/zhifubao.JPG"
WECHAT_QR_SOURCE="${REPO_ROOT}/assets/weixin.JPG"
ICONSET_DIR="${BUILD_DIR}/AppIcon.iconset"
ICON_MASTER="${BUILD_DIR}/AppIcon-master.png"
DEFAULT_APP_VERSION="$(tr -d '\n' < "${REPO_ROOT}/VERSION" 2>/dev/null || printf '1.0.0')"
APP_VERSION="${APP_VERSION_OVERRIDE:-${DEFAULT_APP_VERSION}}"
APP_BUILD="${APP_BUILD:-1}"
APP_ARCHIVE="${BUILD_DIR}/${APP_NAME}-${APP_VERSION}.zip"

build_icon() {
  if [[ ! -f "${ICON_SOURCE}" ]]; then
    return 0
  fi

  rm -rf "${ICONSET_DIR}"
  mkdir -p "${ICONSET_DIR}"

  local width height crop
  width="$(sips -g pixelWidth "${ICON_SOURCE}" | awk '/pixelWidth:/ {print $2}')"
  height="$(sips -g pixelHeight "${ICON_SOURCE}" | awk '/pixelHeight:/ {print $2}')"
  crop="${width}"
  if (( height < crop )); then
    crop="${height}"
  fi

  sips -c "${crop}" "${crop}" "${ICON_SOURCE}" --out "${ICON_MASTER}" >/dev/null

  local entries=(
    "16:icon_16x16.png"
    "32:icon_16x16@2x.png"
    "32:icon_32x32.png"
    "64:icon_32x32@2x.png"
    "128:icon_128x128.png"
    "256:icon_128x128@2x.png"
    "256:icon_256x256.png"
    "512:icon_256x256@2x.png"
    "512:icon_512x512.png"
    "1024:icon_512x512@2x.png"
  )

  local entry size name
  for entry in "${entries[@]}"; do
    size="${entry%%:*}"
    name="${entry#*:}"
    sips -z "${size}" "${size}" "${ICON_MASTER}" --out "${ICONSET_DIR}/${name}" >/dev/null
  done

  iconutil -c icns "${ICONSET_DIR}" -o "${RES_DIR}/AppIcon.icns"
}

rm -rf "${APP_DIR}"
mkdir -p "${BIN_DIR}" "${RES_DIR}"

"${REPO_ROOT}/mac_app/swift-cli/build_swift_cli.sh"

swiftc \
  -parse-as-library \
  -target arm64-apple-macos14.0 \
  -framework SwiftUI \
  -framework AppKit \
  -framework IOKit \
  -framework SystemConfiguration \
  "${SCRIPT_DIR}/RK356xToolkitGUI.swift" \
  -o "${BIN_PATH}"

cat >"${APP_DIR}/Contents/Info.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleDevelopmentRegion</key>
  <string>en</string>
  <key>CFBundleExecutable</key>
  <string>${APP_NAME}</string>
  <key>CFBundleIdentifier</key>
  <string>com.tspi.rk356x.toolkit.gui</string>
  <key>CFBundleIconFile</key>
  <string>AppIcon</string>
  <key>CFBundleInfoDictionaryVersion</key>
  <string>6.0</string>
  <key>CFBundleName</key>
  <string>${APP_NAME}</string>
  <key>CFBundlePackageType</key>
  <string>APPL</string>
  <key>CFBundleShortVersionString</key>
  <string>${APP_VERSION}</string>
  <key>CFBundleVersion</key>
  <string>${APP_BUILD}</string>
  <key>LSMinimumSystemVersion</key>
  <string>14.0</string>
  <key>LSUIElement</key>
  <true/>
  <key>NSHighResolutionCapable</key>
  <true/>
</dict>
</plist>
EOF

build_icon

if [[ -f "${INFO_LOGO_SOURCE}" ]]; then
  cp -f "${INFO_LOGO_SOURCE}" "${RES_DIR}/AppInfoLogo.png"
fi

if [[ -f "${ALIPAY_QR_SOURCE}" ]]; then
  cp -f "${ALIPAY_QR_SOURCE}" "${RES_DIR}/ContactAlipay.jpg"
fi

if [[ -f "${WECHAT_QR_SOURCE}" ]]; then
  cp -f "${WECHAT_QR_SOURCE}" "${RES_DIR}/ContactWeChat.jpg"
fi

copy_runtime_file() {
  local source="$1"
  local target="${RUNTIME_DIR}/$2"
  mkdir -p "$(dirname "${target}")"
  cp -f "${source}" "${target}"
}

copy_runtime_dir() {
  local source="$1"
  local target="${RUNTIME_DIR}/$2"
  mkdir -p "${target}"
  rsync -a "${source}/" "${target}/"
}

copy_runtime_glob() {
  local dir="$1"
  local target="$2"
  shift 2
  mkdir -p "${RUNTIME_DIR}/${target}"
  local pattern
  for pattern in "$@"; do
    for matched in ${dir}/${pattern}; do
      if [[ -f "${matched}" ]]; then
        cp -f "${matched}" "${RUNTIME_DIR}/${target}/"
      fi
    done
  done
}

mkdir -p "${RUNTIME_DIR}"
printf '%s\n' "${APP_VERSION}" > "${RUNTIME_DIR}/VERSION"
copy_runtime_file "${REPO_ROOT}/Dockerfile" "Dockerfile"
copy_runtime_file "${REPO_ROOT}/rk356xctl" "rk356xctl"
copy_runtime_file "${REPO_ROOT}/mac_app/swift-cli/build/rk356xctl-swift" "rk356xctl-swift"
chmod +x "${RUNTIME_DIR}/rk356xctl" "${RUNTIME_DIR}/rk356xctl-swift"

copy_runtime_file "${REPO_ROOT}/lib/common.sh" "lib/common.sh"

for script in \
  build.sh \
  check_host_env.sh \
  detect_rk_usb_mac.sh \
  flash_images.sh \
  flash_partition.sh \
  install_codex_plugin.sh \
  install_host_privileges.sh \
  install_opencode_plugin.sh \
  setup_usbnet_mac.sh \
  usb_authorize_key.sh \
  usb_reboot_device.sh \
  usb_reboot_loader.sh
do
  copy_runtime_file "${REPO_ROOT}/host_runtime/${script}" "host_runtime/${script}"
done

copy_runtime_file "${REPO_ROOT}/rkflashtool-mac/flash_partitions.sh" "rkflashtool-mac/flash_partitions.sh"
copy_runtime_glob "${REPO_ROOT}/rkflashtool-mac/build/bin" "rkflashtool-mac/build/bin" "*"
copy_runtime_file "${REPO_ROOT}/rkflashtool-mac/licenses/THIRD_PARTY.md" "rkflashtool-mac/licenses/THIRD_PARTY.md"

copy_runtime_file "${REPO_ROOT}/product_release/release-installer/distribution.env" "product_release/release-installer/distribution.env"
copy_runtime_file "${REPO_ROOT}/product_release/release-installer/update_toolkit_from_server.sh" "product_release/release-installer/update_toolkit_from_server.sh"
copy_runtime_file "${REPO_ROOT}/product_release/release-installer/update_host_images_from_server.sh" "product_release/release-installer/update_host_images_from_server.sh"

copy_runtime_dir "${REPO_ROOT}/codex_plugin/plugins/rk356x-mac-toolkit" "codex_plugin/plugins/rk356x-mac-toolkit"
copy_runtime_file "${REPO_ROOT}/codex_plugin/plugins/install_local_plugin.sh" "codex_plugin/plugins/install_local_plugin.sh"
copy_runtime_file "${REPO_ROOT}/codex_plugin/.agents/plugins/marketplace.json" "codex_plugin/.agents/plugins/marketplace.json"

copy_runtime_dir "${REPO_ROOT}/opencode_plugin/opencode/plugins" "opencode_plugin/opencode/plugins"
copy_runtime_file "${REPO_ROOT}/opencode_plugin/opencode/install_global.sh" "opencode_plugin/opencode/install_global.sh"
copy_runtime_file "${REPO_ROOT}/opencode_plugin/opencode/package.json" "opencode_plugin/opencode/package.json"

for script in \
  build_official_image.sh \
  check_release_env.sh \
  install_full_environment.sh \
  seed_official_volume.sh \
  update_dtb_host.sh \
  update_logo_host.sh
do
  copy_runtime_file "${REPO_ROOT}/product_release/release-kit/official-docker/${script}" "product_release/release-kit/official-docker/${script}"
done

copy_runtime_file "${REPO_ROOT}/product_release/release-kit/official-docker/lib/common.sh" "product_release/release-kit/official-docker/lib/common.sh"
copy_runtime_file "${REPO_ROOT}/product_release/env_release/generate_embedded_release_tools.py" "product_release/env_release/generate_embedded_release_tools.py"

for template in \
  BOOT_FLEX_README.md \
  build_cross_internal.sh \
  inspect_boot.sh \
  package_userdata_internal.sh \
  update_dtb.sh \
  update_logo.sh
do
  copy_runtime_file "${REPO_ROOT}/product_release/release-kit/official-docker/workspace-templates/${template}" "product_release/release-kit/official-docker/workspace-templates/${template}"
done

find "${RUNTIME_DIR}" -type f \( -name '*.sh' -o -name 'rk356xctl' \) -exec chmod +x {} +

rm -f "${APP_ARCHIVE}"
(cd "${BUILD_DIR}" && ditto -c -k --sequesterRsrc --keepParent "${APP_NAME}.app" "$(basename "${APP_ARCHIVE}")")

echo "Built app: ${APP_DIR}"
echo "Archive: ${APP_ARCHIVE}"
echo "Run: open \"${APP_DIR}\""
